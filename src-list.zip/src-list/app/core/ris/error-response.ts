export class ErrorResponse {
    public message: string;
}
