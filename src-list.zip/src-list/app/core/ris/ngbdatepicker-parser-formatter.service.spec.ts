import { DatePipe } from '@angular/common';
import { inject, TestBed } from '@angular/core/testing';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgbDatePickerParserFormatterService } from './ngbdatepicker-parser-formatter.service';

describe('Service: DateParserFormatterService', () => {
    let service: NgbDatePickerParserFormatterService;
    let mockNgbDateParserFormatterService: MockNgbDateParserFormatterService;

    class MockNgbDateParserFormatterService {
        public format(date: NgbDateStruct): string {
            return null;
        }
        public parse(value: string): NgbDateStruct {
            return null;
        }
    }
    beforeEach(() => {
        mockNgbDateParserFormatterService = new MockNgbDateParserFormatterService();
        TestBed.configureTestingModule({
            providers: [NgbDatePickerParserFormatterService],
        });
        service = TestBed.get(NgbDatePickerParserFormatterService);
    });

    it('should ...', inject([NgbDatePickerParserFormatterService], (dateParserFormatterService: NgbDatePickerParserFormatterService) => {
        expect(NgbDatePickerParserFormatterService).toBeTruthy();
    }));

    // tslint:disable-next-line: max-line-length
    it('should call format and return formatted string', () => {
        // Arrange
        const date = new Date();
        const dateTransformed = new DatePipe('en-US').transform(date, 'dd-MMM-yyyy');
        const dateToNgbStruct = { day: date.getUTCDay(), month: date.getUTCMonth(), year: date.getUTCFullYear() };
        spyOn(mockNgbDateParserFormatterService, 'format').and.returnValue(dateTransformed);

        // Act
        const convertToFormat = mockNgbDateParserFormatterService.format(dateToNgbStruct);

        // Assert
        expect(mockNgbDateParserFormatterService.format).toHaveBeenCalled();
        expect(convertToFormat).toBe(dateTransformed);
    });

    it('should call parse and return NgbDateStruct', () => {
        // Arrange
        const parseString = '11-12-2019';
        const dateParts = new DatePipe('en-US').transform(parseString, 'd-M-y').split('-');
        // tslint:disable-next-line: max-line-length
        // tslint:disable-next-line: radix
        const returnVal = { year: parseInt(dateParts[2]), month: parseInt(dateParts[0]), day: parseInt(dateParts[1]) };
        spyOn(mockNgbDateParserFormatterService, 'parse').and.returnValue(returnVal);

        // Act
        const convertToNgbDateStruct = mockNgbDateParserFormatterService.parse(parseString);

        // Assert
        expect(mockNgbDateParserFormatterService.parse).toHaveBeenCalled();
        expect(convertToNgbDateStruct).toBe(returnVal);
    });
});
