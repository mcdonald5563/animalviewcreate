/* tslint:disable:no-unused-variable */

import { inject, TestBed } from '@angular/core/testing';
import { Guid } from 'guid-typescript';
import { ApplicationStorageService } from './application-storage.service';

describe('Service: ApplicationStorage', () => {
    let service: ApplicationStorageService;

    beforeEach(() => {
        let store = {};

        spyOn(sessionStorage, 'getItem').and.callFake((key: string): string => {
            return store[key] || null;
        });
        spyOn(sessionStorage, 'removeItem').and.callFake((key: string): void => {
            delete store[key];
        });
        spyOn(sessionStorage, 'setItem').and.callFake((key: string, value: string): string => {
            return (store[key] = value as string);
        });
        spyOn(sessionStorage, 'clear').and.callFake(() => {
            store = {};
        });
    });

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ApplicationStorageService],
        });
        service = TestBed.get(ApplicationStorageService);
    });

    it('should ...', inject([ApplicationStorageService], (storageService: ApplicationStorageService) => {
        expect(storageService).toBeTruthy();
    }));

    it('should store the object and return value from session storage when calling get object with existing key ', () => {
        // Arrange

        const storedObject = 'stored value';
        const key = 'Test123';
        service.storeObject(key, storedObject);

        // Act
        const retrievedObject = service.getObject<string>(key);

        // Assert
        expect(sessionStorage.setItem).toHaveBeenCalled();
        expect(retrievedObject).toBe(storedObject);
    });

    it('should store the object with new key and return value from session storage when calling get object ', () => {
        // Arrange

        const storedObject = 'stored value';
        const key = Guid.create().toString();

        spyOn(service, 'getNewStorageKey').and.returnValue(key);
        service.storeObjectWithNewKey(storedObject);

        // Act
        const retrievedObject = service.getObject<string>(key);

        // Assert
        expect(sessionStorage.setItem).toHaveBeenCalled();
        expect(retrievedObject).toBe(storedObject);
    });
    it('should store delete stored session object successfully ', () => {
        // Arrange

        const storedObject = 'stored delete value';
        const key = Guid.create().toString();

        spyOn(service, 'getNewStorageKey').and.returnValue(key);
        const newKey = service.storeObjectWithNewKey(storedObject);

        // Act
        service.deleteObject(newKey);

        // Assert
        expect(sessionStorage.removeItem).toHaveBeenCalled();
    });
});
