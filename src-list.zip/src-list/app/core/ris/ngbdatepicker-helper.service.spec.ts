/* tslint:disable:no-unused-variable */

import { inject, TestBed } from '@angular/core/testing';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgbDatePickerHelperService } from './ngbdatepicker-helper.service';

describe('Service: DateParserFormatterService', () => {
    let service: NgbDatePickerHelperService;
    let mockNgbDatePickerHelperService: MockNgbDatePickerHelperService;

    class MockNgbDatePickerHelperService {
        public ToUtcDateTime(dateStruct: NgbDateStruct): string {
            return null;
        }
        public toNgbDateStruct(date: Date): NgbDateStruct {
            return null;
        }
    }

    beforeEach(() => {
        mockNgbDatePickerHelperService = new MockNgbDatePickerHelperService();
        TestBed.configureTestingModule({
            providers: [NgbDatePickerHelperService],
        });
        service = TestBed.get(NgbDatePickerHelperService);
    });

    it('should ...', inject([NgbDatePickerHelperService], (datePickerHelperService: NgbDatePickerHelperService) => {
        expect(NgbDatePickerHelperService).toBeTruthy();
    }));

    // tslint:disable-next-line: max-line-length
    it('should call ToUtcDateTime with date struct object and convert date to iso string and should call toNgbDateStruct with date object should return ngbstruct', () => {
        // Arrange
        const dateToISO = new Date().toISOString();
        const date = new Date();
        const dateIsoString = date.toISOString();
        const dateToNgbStruct = { day: date.getUTCDay(), month: date.getUTCMonth(), year: date.getUTCFullYear() };
        spyOn(mockNgbDatePickerHelperService, 'ToUtcDateTime').and.returnValue(dateToISO);
        spyOn(mockNgbDatePickerHelperService, 'toNgbDateStruct').and.returnValue(dateToNgbStruct);

        // Act
        const convertToUtcDateTime = mockNgbDatePickerHelperService.ToUtcDateTime(dateToNgbStruct);
        const convertToNgbDateStruct = mockNgbDatePickerHelperService.toNgbDateStruct(date);

        // Assert
        expect(mockNgbDatePickerHelperService.ToUtcDateTime).toHaveBeenCalled();
        expect(mockNgbDatePickerHelperService.toNgbDateStruct).toHaveBeenCalled();
        expect(convertToUtcDateTime).toBe(dateIsoString);
        expect(convertToNgbDateStruct).toBe(dateToNgbStruct);
    });

    it('should call ToUtcDateTime with date struct object NaN values and return null', () => {
        // Arrange
        const dateToNgbStruct = { day: NaN, month: NaN, year: NaN };
        spyOn(mockNgbDatePickerHelperService, 'ToUtcDateTime').and.returnValue(null);

        // Act
        const convertToUtcDateTime = mockNgbDatePickerHelperService.ToUtcDateTime(dateToNgbStruct);

        // Assert
        expect(mockNgbDatePickerHelperService.ToUtcDateTime).toHaveBeenCalled();
        expect(convertToUtcDateTime).toBe(null);
    });
});
