/* tslint:disable:no-unused-variable */
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../../environments/environment';
import { ErrorLogService } from './error-log.service';
import { UserSecurityInfo } from './models/user-security-info.model';
import { SecurityService } from './security.service';

describe('Service: Security', () => {
    const userSecurityInfo: UserSecurityInfo = require('../../mock-data/user-security-info.mock.json');
    let http: HttpTestingController;
    let service: SecurityService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                SecurityService,
                {
                    provide: ErrorLogService,
                },
            ],
        });
        service = TestBed.get(SecurityService);
        http = TestBed.get(HttpTestingController);
    });

    it('should create an instance', () => {
        expect(service).toBeDefined();
    });

    it('should get user security info by calling getUserSecurityInfo()', () => {
        // Arrange
        const url = `${environment.endpoints.applicationSecurityServiceUrl}/Authorize/Validate`;
        let responseData: any;
        const data = userSecurityInfo;

        // Act
        service.getUserSecurityInfo().subscribe((res) => (responseData = res));
        const req = http.expectOne({ url, method: 'POST' });
        req.flush(data);

        // Assert
        http.verify();
        expect(responseData.personId).toBe(data.personId);
        expect(responseData.loginId).toBe(data.loginId);
        expect(responseData.contactName).toBe(data.contactName);
        expect(responseData.authorizedPermissions[0].permissionId).toBe(data.authorizedPermissions[0].permissionId);
        expect(responseData.authorizedPermissions[0].permissionCode).toBe(data.authorizedPermissions[0].permissionCode);
        expect(responseData.authorizedPermissions[0].inventoryOrgId).toBe(data.authorizedPermissions[0].inventoryOrgId);
    });

    it('should return error when getUserSecurityInfo encounters error', () => {
        // Arrange
        const url = `${environment.endpoints.applicationSecurityServiceUrl}/Authorize/Validate`;
        let responseData: any;
        const data = userSecurityInfo;
        let errResponse: any;
        const errorResponse = { status: 400, statusText: `Error status code 400 at ${url}` };

        // Act
        service.getUserSecurityInfo().subscribe(
            (res) => (responseData = res),
            (err) => (errResponse = err)
        );
        const req = http.expectOne({ url, method: 'POST' });
        req.flush(data, errorResponse);

        // Assert
        http.verify();
        expect(errResponse).toBe(errorResponse.statusText);
    });

    it('should return true when isPermitted has match as single string', () => {
        // Arrange
        service.userSecurityInfo = userSecurityInfo;

        // Act
        const result = service.isPermitted('CREATE');

        // Assert
        expect(result).toBe(true);
    });

    it('should return true when isPermitted has match as string array', () => {
        // Arrange
        service.userSecurityInfo = userSecurityInfo;

        // Act
        const result = service.isPermitted(['CREATE', 'EDIT']);

        // Assert
        expect(result).toBe(true);
    });

    it('should return false when isPermitted has no match', () => {
        // Arrange
        service.userSecurityInfo = userSecurityInfo;

        // Act
        const result = service.isPermitted(['DELETE']);

        // Assert
        expect(result).toBe(false);
    });
});
