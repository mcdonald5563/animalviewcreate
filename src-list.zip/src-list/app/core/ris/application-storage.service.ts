import { Injectable } from '@angular/core';
import { Guid } from 'guid-typescript';

@Injectable({
    providedIn: 'root',
})
export class ApplicationStorageService {
    constructor() {}

    public storeObject(key: string, object: any, useLocalStorage: boolean = false): void {
        if (useLocalStorage) {
            localStorage.setItem(key, JSON.stringify(object));
        } else {
            sessionStorage.setItem(key, JSON.stringify(object));
        }
    }

    public storeObjectWithNewKey(object: any, useLocalStorage: boolean = false): string {
        const key = this.getNewStorageKey();
        this.storeObject(key, object, useLocalStorage);
        return key;
    }

    public deleteObject(key: string, useLocalStorage: boolean = false): void {
        if (useLocalStorage) {
            localStorage.removeItem(key);
        } else {
            sessionStorage.removeItem(key);
        }
    }

    public getObject<T>(key: string, useLocalStorage: boolean = false): T {
        if (useLocalStorage) {
            return JSON.parse(localStorage.getItem(key)) as T;
        } else {
            return JSON.parse(sessionStorage.getItem(key)) as T;
        }
    }

    public getNewStorageKey(): string {
        const guid = Guid.create();
        return guid.toString();
    }
}
