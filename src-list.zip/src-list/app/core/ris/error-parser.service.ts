import { Injectable } from '@angular/core';

export interface IErrorParserService {
    parseErrorMessagesFromErrorResponse(response: any): string[];
}

@Injectable({ providedIn: 'root' })
export class ErrorParserService implements IErrorParserService {
    public parseErrorMessagesFromErrorResponse(response: any): string[] {
        const messages: string[] = [];

        if (response && response.error) {
            for (const error in response.error) {
                if (response.error.hasOwnProperty(error)) {
                    messages.push(response.error[error]);
                }
            }
            return messages;
        }

        if (response && response.error === null) {
            if (response.status === 401) {
                messages.push('Not Authorized! You need permission to access selected resource!');
                return messages;
            }
            messages.push('Error response with unknown messages.');
            return messages;
        }

        messages.push('Unknown Error.');
        return messages;
    }
}
