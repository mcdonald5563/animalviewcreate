import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { HttpGetRequestClient } from './httpget-request.service';

describe('Service: Purchaseorders', () => {
    let service: HttpGetRequestClient;
    let http: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [HttpGetRequestClient],
        });

        http = TestBed.get(HttpTestingController);
        service = TestBed.get(HttpGetRequestClient);
    });

    it('should create an instance', () => {
        expect(service).toBeDefined();
    });
});
