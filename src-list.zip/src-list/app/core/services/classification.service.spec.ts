/* tslint:disable:no-unused-variable */
import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ClassificationsResponse } from '../models/classifications-response.model';
import { ErrorSeverity } from '../ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../ris/error-log.service';
import { ErrorResponse } from '../ris/error-response';
import { ClassificationService } from './classification.service';

describe('Service: Classification', () => {
    const classificationsRespose: ClassificationsResponse = require('../../mock-data/classifications-response.mock.json');

    let http: HttpTestingController;
    let service: ClassificationService;

    beforeEach(() => {
        const mockErrorService = new MockErrorService();

        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                ClassificationService,
                {
                    provide: ErrorLogService,
                    useValue: mockErrorService,
                },
            ],
        });
        service = TestBed.get(ClassificationService);
        http = TestBed.get(HttpTestingController);
    });

    class MockErrorService {
        logError() {
            return null;
        }
        handleHttpError(error: HttpErrorResponse, severity: ErrorSeverity): Observable<ErrorResponse> {
            return null;
        }
    }

    it('should create an instance', () => {
        expect(service).toBeDefined();
    });

    it('should call correct get url', () => {
        // Arrange
        const url = `${environment.endpoints.archetypeServiceUrl}/Animals`;
        let responseData: any;
        const data = classificationsRespose;
        console.log('class respppp', data)
        // Act
        service.getClassifications(null).subscribe((res) => (responseData = res));
        const req = http.expectOne({ url, method: 'GET' });
        req.flush(data);

        // Assert
        http.verify();
        expect(responseData.animals[0].id).toBe(data.animals[0].id);
        expect(responseData.animals[0].name).toBe(data.animals[0].name);
    });
});
