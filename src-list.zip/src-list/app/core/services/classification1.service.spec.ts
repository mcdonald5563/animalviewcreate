/* tslint:disable:no-unused-variable */
import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Classification1Response } from '../models/classification1-response.model';
import { ErrorSeverity } from '../ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../ris/error-log.service';
import { ErrorResponse } from '../ris/error-response';
import { Classification1Service } from './classification1.service';

describe('Service: Classification', () => {
    const classificationRespose: Classification1Response = require('../../mock-data/classification-response.mock.json');

    let http: HttpTestingController;
    let service: Classification1Service;

    beforeEach(() => {
        const mockErrorService = new MockErrorService();

        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                Classification1Service,
                {
                    provide: ErrorLogService,
                    useValue: mockErrorService,
                },
            ],
        });
        service = TestBed.get(Classification1Service);
        http = TestBed.get(HttpTestingController);
    });

    class MockErrorService {
        logError() {
            return null;
        }
        handleHttpError(error: HttpErrorResponse, severity: ErrorSeverity): Observable<ErrorResponse> {
            return null;
        }
    }

    it('should create an instance', () => {
        expect(service).toBeDefined();
    });

    it('should call correct get url', () => {
        // Arrange
        const url = `https://risarchetypedev.nov.cloud/api/v1/Classifications`;
        let responseData: any;
        const data = classificationRespose;
        console.log('class respppp', data)
        // Act
        service.getClassification(url).subscribe((res) => (responseData = res));
        const req = http.expectOne({ url, method: 'GET' });
        req.flush(data);

        // Assert
        http.verify();
        expect(responseData[0].id).toBe(data[0].id);
        expect(responseData[0].name).toBe(data[0].name);
    });
});
