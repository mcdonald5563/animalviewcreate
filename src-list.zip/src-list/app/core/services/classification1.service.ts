import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ClassificationProfile } from '../models/classification-profile.model';
import { Classification1Response } from '../models/classification1-response.model';
import { ErrorSeverity } from '../ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../ris/error-log.service';
import { ErrorResponse } from '../ris/error-response';

export interface IClassification1Service {
    getClassification(ClassificationProfile: any): Observable<Classification1Response | ErrorResponse>;
}

@Injectable({
    providedIn: 'root',
})
export class Classification1Service implements IClassification1Service {
    constructor(private http: HttpClient, private errorLogService: ErrorLogService) { }

    public getClassification(url: string): Observable<Classification1Response | ErrorResponse> {
       // const url = `${environment.endpoints.archetypeServiceUrl}/Animals`;
        //const params = ClassificationProfile;
        return this.http
            .get<Classification1Response>(url)
            .pipe(catchError((err) => this.errorLogService.handleHttpError(err, ErrorSeverity.critical)));
    }
}
