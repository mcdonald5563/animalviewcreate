/* tslint:disable:no-unused-variable */
import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AnimalListProfile } from '../models/animal-list-profile.model';
import { AnimalsResponse } from '../models/animals-response-model';
import { ErrorSeverity } from '../ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../ris/error-log.service';
import { ErrorResponse } from '../ris/error-response';
import { AnimalService } from './animal.service';

describe('Service: Animal', () => {
    const animalsRespose: AnimalsResponse = require('../../mock-data/animals-response.mock.json');

    let http: HttpTestingController;
    let service: AnimalService;

    beforeEach(() => {
        const mockErrorService = new MockErrorService();

        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [
                AnimalService,
                {
                    provide: ErrorLogService,
                    useValue: mockErrorService,
                },
            ],
        });
        service = TestBed.get(AnimalService);
        http = TestBed.get(HttpTestingController);
    });

    class MockErrorService {
        logError() {
            return null;
        }
        handleHttpError(error: HttpErrorResponse, severity: ErrorSeverity): Observable<ErrorResponse> {
            return null;
        }
    }

    it('should create an instance', () => {
        expect(service).toBeDefined();
    });

    it('should call correct get url', () => {
        // Arrange
        const url = `${environment.endpoints.archetypeServiceUrl}/Animals`;
        let responseData: any;
        const data = animalsRespose;
        // Act
        service.getAnimals(null).subscribe((res) => (responseData = res));
        const req = http.expectOne({ url, method: 'GET' });
        req.flush(data);

        // Assert
        http.verify();
        expect(responseData.animals[0].id).toBe(data.animals[0].id);
        expect(responseData.animals[0].name).toBe(data.animals[0].name);
    });
});
