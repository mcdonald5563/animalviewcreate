import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ClassificationProfile } from '../models/classification-profile.model';
import { ClassificationsResponse } from '../models/classifications-response.model';
import { ErrorSeverity } from '../ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../ris/error-log.service';
import { ErrorResponse } from '../ris/error-response';

export interface IClassificationService {
    getClassifications(ClassificationProfile: any): Observable<ClassificationsResponse | ErrorResponse>;
}

@Injectable({
    providedIn: 'root',
})
export class ClassificationService implements IClassificationService {
    constructor(private http: HttpClient, private errorLogService: ErrorLogService) { }

    public getClassifications(ClassificationProfile: any): Observable<ClassificationsResponse | ErrorResponse> {
        const url = `${environment.endpoints.archetypeServiceUrl}/Animals`;
        const params = ClassificationProfile;
        return this.http
            .get<ClassificationsResponse>(url, { params })
            .pipe(catchError((err) => this.errorLogService.handleHttpError(err, ErrorSeverity.critical)));
    }
}
