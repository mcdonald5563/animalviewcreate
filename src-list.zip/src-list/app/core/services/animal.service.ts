import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AnimalsResponse } from '../models/animals-response-model';
import { AnimalResponse } from '../models/animal-response.model';
import { ErrorSeverity } from '../ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../ris/error-log.service';
import { ErrorResponse } from '../ris/error-response';

export interface IAnimalService {
    getAnimals(animalsListProfile: any): Observable<AnimalsResponse | ErrorResponse>;
    getAnimalDetailById(id: number): Observable<AnimalResponse | ErrorResponse>;
    saveAnimalDetail(animalPayload: any): Observable<AnimalResponse | ErrorResponse>;
}

@Injectable({
    providedIn: 'root',
})
export class AnimalService implements IAnimalService {
    constructor(private http: HttpClient, private errorLogService: ErrorLogService) { }

    public getAnimals(animalsListProfile: any): Observable<AnimalsResponse | ErrorResponse> {
        const url = `${environment.endpoints.archetypeServiceUrl}/Animals`;
        const params = animalsListProfile;
        return this.http
            .get<AnimalsResponse>(url, { params })
            .pipe(catchError((err) => this.errorLogService.handleHttpError(err, ErrorSeverity.critical)));
    }

    public getAnimalDetailById(id: number): Observable<AnimalResponse | ErrorResponse> {
        const url = `${environment.endpoints.archetypeServiceUrl}/Animals/${id}`;
        return this.http
            .get<AnimalResponse>(url)
            .pipe(catchError((err) => this.errorLogService.handleHttpError(err, ErrorSeverity.critical)));
    }

    public saveAnimalDetail(animalPayload: any): Observable<AnimalResponse | ErrorResponse> {
        const headers = new HttpHeaders({ 'Context-Type': 'application/json' });
        console.log('payloadddddddddddddddd', animalPayload)
        const url = `${environment.endpoints.archetypeServiceUrl}/Animals`;
        return this.http.put(url, animalPayload, { headers }).pipe(
            map((response: AnimalResponse) => {
                return response;
            }),
            catchError((err) => this.errorLogService.handleHttpError(err, ErrorSeverity.critical))
        );
    }
}
