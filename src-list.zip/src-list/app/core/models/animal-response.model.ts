import { Time } from "@angular/common";

export class AnimalResponse {
    id: number;
    name: string;
    description: string;
    averageLifeSpan: number;
    classificationId: number;
    classificationLink: string;
    classificationName: string;
    discoveredDate: Date;
    nextFeedDateTime: Date;
    createdDateTime: Date;
    createdByLoginId: number;
    updatedDateTime: Date;
    updatedByLoginId: number;
    isVoid: boolean;
    selected: boolean;
}
