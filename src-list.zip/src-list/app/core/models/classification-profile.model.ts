export class ClassificationProfile {
    public keyword: string;
    public url: string;
}
