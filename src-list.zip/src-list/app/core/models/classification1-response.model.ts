export class Classification1Response {
    id: number;
    name: string;
}
