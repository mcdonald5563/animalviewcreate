import { ClassificationResponse } from './classification-response.model';

export class ClassificationsResponse {
    public animals: ClassificationResponse[];
    public totalResultCount: number;
}
