import { Classification1Response } from './classification1-response.model';

export class ClassificationsModel {
    public classifications: Classification1Response[];
    //public totalResultCount: number;
}
