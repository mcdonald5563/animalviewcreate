export class ClassificationResponse {
    id: number;
    name: string;
}
