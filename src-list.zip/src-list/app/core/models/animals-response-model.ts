import { AnimalResponse } from './animal-response.model';
import { Classification1Response } from './classification1-response.model';

export class AnimalsResponse {
    public animals: AnimalResponse[];
    public classifications: Classification1Response[];
    public totalResultCount: number;
}
