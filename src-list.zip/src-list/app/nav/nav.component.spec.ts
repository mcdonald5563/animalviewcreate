/* tslint:disable:no-unused-variable */
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AdalService } from 'adal-angular4';
import { Observable } from 'rxjs';
import { UserSecurityInfo } from '../core/ris/models/user-security-info.model';
import { SecurityService } from '../core/ris/Security.Service';
import { NavComponent } from './nav.component';

@Component({
    selector: 'app-login',
    template: '<div></div>',
})
class FakeLoginComponent {}
// tslint:disable-next-line: max-classes-per-file
class MockSecurityService {
    userSecurityInfo: {};
    getUserSecurityInfo(): Observable<UserSecurityInfo> {
        return null;
    }

    isPermitted(code: string): boolean {
        return true;
    }
}

describe('NavComponent', () => {
    let component: NavComponent;
    let fixture: ComponentFixture<NavComponent>;
    let mockAdalServie: AdalService;
    // tslint:disable-next-line: prefer-const
    let mockSecurityService: MockSecurityService;

    beforeEach(async(() => {
        mockAdalServie = jasmine.createSpyObj(['handleWindowCallback', 'userInfo', 'login', 'logOut']);
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, NgbModule, HttpClientTestingModule],
            declarations: [NavComponent, FakeLoginComponent],
            providers: [
                { provide: AdalService, useValue: mockAdalServie },
                { provide: MockSecurityService, useValue: mockSecurityService },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NavComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
