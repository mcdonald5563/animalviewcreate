import { ApplicationInitStatus, Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AccessDeniedComponent } from './ris/access-denied/access-denied.component';
import { AuthenticationCallbackComponent } from './ris/authentication/authentication-callback.component';
import { AuthenticationGuard } from './ris/authentication/authentication.guard';
import { NotFoundComponent } from './ris/not-found/not-found.component';
import { SignOutComponent } from './ris/sign-out/sign-out.component';
import { StyleguideComponent } from './styleguide/styleguide.component';

const routes: Routes = [
    {
        path: 'oauth2-callback',
        component: AuthenticationCallbackComponent,
    },
    {
        path: 'home',
        component: HomeComponent,
    },
    {
        path: 'styleguide',
        component: StyleguideComponent,
        loadChildren: './styleguide/styleguide.module#StyleguideModule',
        canActivate: [AuthenticationGuard],
    },
    {
        path: 'accessdenied',
        component: AccessDeniedComponent,
    },
    {
        path: 'animal',
        loadChildren: './animal/animal.module#AnimalModule',
        canActivate: [AuthenticationGuard],
    },
    {
        path: 'signout',
        component: SignOutComponent,
    },
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: '**', component: NotFoundComponent },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule {}
