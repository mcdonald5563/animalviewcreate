import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

import { AnimalService } from '../../core/services/animal.service';
import { AnimalEditViewModel } from './animal-edit-viewmodel.model';
import { AnimalResponse } from '../../core/models/animal-response.model';
import { Classification1Response } from 'src/app/core/models/classification1-response.model';
import { Classification1Service } from '../../core/services/classification1.service';
import { AlertifyService } from '../../core/ris/alertify.service';

@Component({
    selector: 'app-item-edit',
    templateUrl: './animal-edit.component.html',
    styleUrls: ['./animal-edit.component.scss'],
})
export class AnimalEditComponent implements OnInit {
    dateModel: NgbDateStruct;
    vm: AnimalEditViewModel;
    saveAnimalErrorMessage = '';
    isLoading: boolean;
    isItemTypeExcluded: boolean;
    isApprovedStatus: boolean;
    isSubmitButtonLoading = false;
    submitted = false;
    failedSubmit = false;
    editAnimal: AnimalResponse;
    public classifications: Classification1Response[] = [
        {
            id: 2,
            name: 'Amphibians'
        },
        {
            id: 1,
            name: 'Mammals'
        },
    ];

    constructor(
        private route: ActivatedRoute,
        private animalService: AnimalService,
        private classification1Service: Classification1Service,
        private alertifyService: AlertifyService,
        private router: Router,
    ) {
        this.vm = new AnimalEditViewModel();
    }

    ngOnInit() {
        this.route.params.subscribe((params) => {
            if (params && params['id']) {
                const id = params['id'];
                console.log('edit animal id', id);
                this.getAnimalByID(id);
            }
        });
    }
    public getAnimalByID(id: number) {
        this.vm.isInfo = false;
        this.vm.isOk = false;
        this.vm.isLoadingAnimal = true;
        this.vm.id = id;
        this.animalService.getAnimalDetailById(id).subscribe((animalResponse: AnimalResponse) => {
            this.vm.isLoadingAnimal = false;
            this.vm.isOk = true;
            this.vm.id = animalResponse.id;
            this.vm.name = animalResponse.name;
            this.vm.description = animalResponse.description;
            this.vm.averageLifeSpan = animalResponse.averageLifeSpan;
            this.vm.classificationId = animalResponse.classificationId;
            this.vm.classificationLink = animalResponse.classificationLink;
            this.vm.discoveredDate = animalResponse.discoveredDate;
            this.vm.nextFeedDateTime = animalResponse.nextFeedDateTime ? new Date(animalResponse.nextFeedDateTime).toISOString().split('.')[0] : '';
            this.vm.isVoid = animalResponse.isVoid;
            const url = animalResponse.classificationLink;
            // this.getClassificationName(url);
            console.log('edit animal response', animalResponse)
        });
    }

    public getClassificationName(url) {
        this.classification1Service
            .getClassification(url)
            .subscribe((classification: Classification1Response) => {
                if (classification) {
                    //this.classifications.push(classification);
                    this.vm.classificationName = classification.name;
                }
            });
    }

    public saveAnimalDetail() {
        console.log('changed VMMMMMMMMMMMMMMMMM', this.vm)
        this.saveAnimalErrorMessage = '';
        const animalPayload = {
            "id": this.vm.id,
            "name": this.vm.name,
            "description": this.vm.description,
            "classificationId": this.vm.classificationId,
            "averageLifeSpan": this.vm.averageLifeSpan,
            "discoveredDate": this.vm.discoveredDate || "",
            "nextFeedDateTime": this.vm.nextFeedDateTime || ""
        };

        this.animalService.saveAnimalDetail(animalPayload).subscribe(
            () => { },
            () => {
                this.failedSubmit = true;
                this.submitted = false;
                this.isSubmitButtonLoading = false;
                this.saveAnimalErrorMessage = 'Failed to save animal details.';
            },
            () => {
                this.failedSubmit = false;
                this.submitted = true;
                this.alertifyService.success('Animal Details saved successfully', '');
                this.isSubmitButtonLoading = false;
                this.router.navigate([`/animal/view/${this.vm.id}`]);
            }
        );
    }

}