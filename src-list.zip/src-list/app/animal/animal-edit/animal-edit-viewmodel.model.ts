import { Time } from "@angular/common";

export class AnimalEditViewModel {
    id: number;
    name: string;
    description: string;
    averageLifeSpan: number;
    classificationId: number;
    classificationLink: string;
    classificationName: string;
    discoveredDate: Date;
    nextFeedDateTime: string;
    isVoid: boolean;
    selected: boolean;
    isInfo: boolean;
    isWarning: boolean;
    isLoadingAnimal: boolean;
    isOk: boolean;

    public constructor() {
        this.id = null;
        this.name = null;
        this.description = null;
        this.averageLifeSpan = null;
        this.classificationId = null;
        this.classificationLink = null;
        this.classificationName = null;
        this.discoveredDate = null;
        this.nextFeedDateTime= null;
        this.isVoid = false;
        this.isInfo = true;
        this.isWarning = false;
        this.isLoadingAnimal = false;
        this.isOk = false;
    }
}
