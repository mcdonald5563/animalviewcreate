import { TestBed } from '@angular/core/testing';

import { AnimalListService } from './animal-list.service';

describe('AnimalListService', () => {
    beforeEach(() => TestBed.configureTestingModule({}));

    it('should be created', () => {
        const service: AnimalListService = TestBed.get(AnimalListService);
        expect(service).toBeTruthy();
    });
});
