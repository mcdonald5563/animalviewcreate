import { Component, OnInit } from '@angular/core';
import { AnimalResponse } from '../../core/models/animal-response.model';
import { AnimalsResponse } from '../../core/models/animals-response-model';
import { ClassificationResponse } from '../../core/models/classification-response.model';
import { Classification1Response } from '../../core/models/classification1-response.model'
import { ClassificationsResponse } from '../../core/models/classifications-response.model';
import { ClassificationsModel } from '../../core/models/classifications1.model';
import { ErrorResponse } from '../../core/ris/error-response';
import { AnimalService } from '../../core/services/animal.service';
import { ClassificationService } from '../../core/services/classification.service';
import { Classification1Service } from '../../core/services/classification1.service';
import { AnimalListViewModel } from './animal-list-viewmodel.model'

@Component({
    selector: 'app-animal-list',
    templateUrl: './animal-list.component.html',
    styleUrls: ['./animal-list.component.scss'],
})
export class AnimalListComponent implements OnInit {
    vm: AnimalListViewModel;
    public animals: AnimalResponse[];

    public classifications: Classification1Response[] = [];
    public classificationsList: Classification1Response[] = [
        {
            id: 1,
            name: 'Mammals'
        },
        {
            id: 2,
            name: 'Amphibians'
        },
    ];
    public animalsList: any[];
    public animalsDropdownValues: any[];
    public totalResultCount: number;
    page = 1;
    pageSize = 10;
    search: AnimalResponse;
    public clearScreen() {
        this.animalsList = [];
        this.vm.isInfo = true;
        this.vm.isOk = false;
        this.vm.isStatusWarning = false;
    }
    constructor(private animalService: AnimalService,
        private classification1Service: Classification1Service) {
        this.search = new AnimalResponse();

        this.getAminalsList();

    }

    searchAnimals(name: string, selectedClassifications: any[]) {
        //console.log('name selectedClassifications', name, selectedClassifications);
        this.clearScreen();
        if ((name != undefined && name.length == 0 && selectedClassifications != undefined && selectedClassifications.length == 0) || (name == undefined && selectedClassifications == undefined) || (name && name.length == 0 && selectedClassifications == undefined) || (name == undefined && selectedClassifications && selectedClassifications.length == 0)) {
            this.animalsList = this.animals;
            this.vm.isInfo = false;
            this.vm.isOk = true;
            //console.log('came innnnn 1111111111111111')
        } else if (name && name.length > 0 && (selectedClassifications == undefined || selectedClassifications && selectedClassifications.length == 0)) {
            this.animalsList = this.animals.filter(animal => animal.name == name);
            this.vm.isInfo = false;
            this.vm.isOk = true;
            //console.log('came innnnn 2222222222222222222')
        } else if ((name == undefined || name && name.length == 0) && selectedClassifications.length > 0) {
            let animalsByClassification = [];
            selectedClassifications.map(classf => {
                let classficationAnimal = this.animals.filter(animal => animal.classificationId == classf);
                animalsByClassification = animalsByClassification.concat(classficationAnimal);
            })
            this.animalsList = animalsByClassification
            this.vm.isInfo = false;
            this.vm.isOk = true;
            //console.log('came innnnn 33333333333333333333333')
        } else if (name && name.length > 0 && selectedClassifications && selectedClassifications.length > 0) {
            let animalsByNameClassif = [];
            selectedClassifications.map(classf => {
                let classficationAnimal = this.animals.filter(animal => animal.name == name && animal.classificationId == classf);
                animalsByNameClassif = animalsByNameClassif.concat(classficationAnimal);
            })
            this.animalsList = animalsByNameClassif;
            this.vm.isInfo = false;
            this.vm.isOk = true;
            //console.log('came innnnn 44444444444444444444444')
        }


        // if ((name == undefined && selectedClassifications == undefined) || (name.length == 0 && selectedClassifications.length == 0)) {
        //     this.animalsList = this.animals;
        //     this.vm.isInfo = false;
        //     this.vm.isOk = true;
        //     console.log('came innnnn 1111111111111111')
        // } else if ((selectedClassifications == undefined || selectedClassifications.length == 0) && name && name.length > 0) {
        //     this.animalsList = this.animals.filter(animal => animal.name == name);
        //     this.vm.isInfo = false;
        //     this.vm.isOk = true;
        //     console.log('came innnnn 2222222222222222222')
        // }
        // else if ((name == undefined) && selectedClassifications && selectedClassifications.length > 0) {
        //     let animalsByClassification = [];
        //     selectedClassifications.map(classf => {
        //         let classficationAnimal = this.animals.filter(animal => animal.classificationId == classf);
        //         animalsByClassification = animalsByClassification.concat(classficationAnimal);
        //     })
        //     this.animalsList = animalsByClassification
        //     this.vm.isInfo = false;
        //     this.vm.isOk = true;
        //     console.log('came innnnn 333333')
        // }
        // else if ((selectedClassifications && selectedClassifications.length >0) && name && name.length > 0) {
        //     this.animalsList = this.animals.filter(animal => animal.name == name);
        //     this.vm.isInfo = false;
        //     this.vm.isOk = true;
        // }
        // else {
        //     this.animalsList = this.animals.filter(animal => animal.name == name && animal.classificationId == classificationId);
        //     this.vm.isInfo = false;
        //     this.vm.isOk = true;
        // }
    }

    ngOnInit() {
        this.vm = new AnimalListViewModel();
    }

    public getAminalsList() {
        this.animalService.getAnimals(null).subscribe(
            (data: AnimalsResponse) => {
                this.animals = data.animals;
                this.animalsDropdownValues = data.animals;
                this.animalsList = data.animals;
                this.totalResultCount = data.animals.length;
                this.animals.forEach((animal, index) => {
                    const url = animal.classificationLink;
                    this.getClassificationNames(url, index);
                });
            },
            (err: ErrorResponse) => '',
            () => ''
        );

    }
    public getClassificationNames(url, index) {
        this.classification1Service
            .getClassification(url)
            .subscribe((classification: Classification1Response) => {
                if (classification) {
                    this.classifications.push(classification);
                    this.animalsList[index].classificationName = classification.name;
                    this.animals[index].classificationName = classification.name;

                }
            });
    }
}
