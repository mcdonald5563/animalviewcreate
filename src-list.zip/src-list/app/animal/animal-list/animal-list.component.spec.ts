import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select'
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs';
import { AnimalsResponse } from '../../core/models/animals-response-model';
import { ClassificationsResponse } from '../../core/models/classifications-response.model';
import { ErrorResponse } from '../../core/ris/error-response';
import { AnimalService } from '../../core/services/animal.service';
import { ClassificationService } from '../../core/services/classification.service';
import { AnimalListComponent } from './animal-list.component'; //'./tables.component';

describe('AnimalListComponent', () => {
    let component: AnimalListComponent;
    let fixture: ComponentFixture<AnimalListComponent>;

    beforeEach(async(() => {
        const mockAnimalService = new MockAnimalService();
        TestBed.configureTestingModule({
            imports: [FormsModule, RouterTestingModule, NgbModule, NgSelectModule],
            providers: [
                AnimalService,
                {
                    provide: AnimalService,
                    useValue: mockAnimalService,
                },
            ],
            declarations: [AnimalListComponent],
        }).compileComponents();

        fixture = TestBed.createComponent(AnimalListComponent);
        component = fixture.componentInstance;
    }));

    class MockAnimalService {
        getAnimals(animalListProfile: any): Observable<AnimalsResponse | ErrorResponse> {
            return null;
        }
    }

    it('should create component instance', () => {
        expect(component).toBeDefined();
    });
});

