export class AnimalListViewModel {   
    isInfo: boolean;
    isWarning: boolean;
    isLoadingSearch: boolean;
    isOk: boolean;
    isStatusWarning: boolean;

    public constructor() {
        this.isInfo = true;
        this.isWarning = false;
        this.isLoadingSearch = false;
        this.isOk = false;
        this.isStatusWarning = false;
    }
}
