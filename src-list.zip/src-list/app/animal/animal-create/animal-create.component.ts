import { Component, OnInit } from '@angular/core';
import { AnimalCreateService } from './animal-create.service';

@Component({
    selector: 'app-animal-create',
    templateUrl: './animal-create.component.html',
    styleUrls: ['./animal-create.component.scss'],
})
export class AnimalCreateComponent implements OnInit {
    constructor(private animalCreateService: AnimalCreateService) {}

    ngOnInit() {}
}
