import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnimalCreateComponent } from './animal-create/animal-create.component' //'./item-inquiry/item-inquiry.component';
import { AnimalListComponent } from './animal-list/animal-list.component';
import {AnimalViewComponent} from './animal-view/animal-view.component';
import {AnimalEditComponent} from './animal-edit/animal-edit.component';

const routes: Routes = [
    {
        path: '',
        component: AnimalListComponent,
        data: { title: 'Animal List' }
    },
    {
        path: 'view/:id',
        component: AnimalViewComponent,
        data: { title: 'Animal View' },
    },
    {
        path: 'edit/:id',
        component: AnimalEditComponent,
        data: { title: 'Animal Edit' },
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AnimalRoutingModule { }
