import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { NgbModule, NgbTypeaheadModule } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { AnimalCreateComponent } from './animal-create/animal-create.component';
import { AnimalListComponent } from './animal-list/animal-list.component';
import { AnimalViewComponent } from './animal-view/animal-view.component'
import { AnimalEditComponent } from './animal-edit/animal-edit.component'
import { AnimalRoutingModule } from './animal-routing.module'

@NgModule({
    declarations: [AnimalCreateComponent, AnimalListComponent, AnimalViewComponent, AnimalEditComponent],
    imports: [CommonModule, FormsModule, AnimalRoutingModule, NgbTypeaheadModule, NgbModule, NgSelectModule],
})
export class AnimalModule { }
