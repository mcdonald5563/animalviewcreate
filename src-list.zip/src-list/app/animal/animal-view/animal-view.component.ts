import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

import { AnimalService } from '../../core/services/animal.service';
import { AnimalViewModel } from './animal-view-viewmodel.model';
import { AnimalResponse } from '../../core/models/animal-response.model';
import { Classification1Response } from 'src/app/core/models/classification1-response.model';
import { Classification1Service } from '../../core/services/classification1.service';
import { AlertifyService } from '../../core/ris/alertify.service';

@Component({
    selector: 'app-animal-view',
    templateUrl: './animal-view.component.html',
    styleUrls: ['./animal-view.component.scss'],
})
export class AnimalViewComponent implements OnInit {
    dateModel: NgbDateStruct;
    vm: AnimalViewModel;
    isLoading: boolean;

    constructor(
        private route: ActivatedRoute,
        private animalService: AnimalService,
        private classification1Service: Classification1Service,
        private router: Router,
    ) {
        this.vm = new AnimalViewModel();
    }

    ngOnInit() {
        this.route.params.subscribe((params) => {
            if (params && params['id']) {
                const id = params['id'];
                this.getAnimalByID(id);
            }
        });
    }
    public getAnimalByID(id: number) {
        this.vm.isInfo = false;
        this.vm.isOk = false;
        this.vm.isLoadingAnimal = true;
        this.vm.id = id;
        this.animalService.getAnimalDetailById(id).subscribe((animalResponse: AnimalResponse) => {
            console.log('animals responnnn', animalResponse)
            this.vm.isLoadingAnimal = false;
            this.vm.isOk = true;
            this.vm.id = animalResponse.id;
            this.vm.name = animalResponse.name;
            this.vm.description = animalResponse.description;
            this.vm.averageLifeSpan = animalResponse.averageLifeSpan;
            this.vm.classificationId = animalResponse.classificationId;
            this.vm.classificationLink = animalResponse.classificationLink;
            this.vm.discoveredDate = animalResponse.discoveredDate;
            this.vm.nextFeedDateTime = animalResponse.nextFeedDateTime;
            this.vm.createdByLoginId = animalResponse.createdByLoginId;
            this.vm.createdDateTime = animalResponse.createdDateTime;
            this.vm.updatedByLoginId = animalResponse.updatedByLoginId;
            this.vm.updatedDateTime = animalResponse.updatedDateTime;
            this.vm.isVoid = animalResponse.isVoid;
            const url = animalResponse.classificationLink;
            this.getClassificationName(url);
        });
    }

    public getClassificationName(url) {
        this.classification1Service
            .getClassification(url)
            .subscribe((classification: Classification1Response) => {
                console.log('classificationRespo++++', classification)
                if (classification) {
                    //this.classifications.push(classification);
                    this.vm.classificationName = classification.name;
                }
            });
    }


}