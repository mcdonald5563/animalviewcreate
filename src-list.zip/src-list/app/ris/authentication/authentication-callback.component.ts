import { Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdalService } from 'adal-angular4';
// tslint:disable-next-line: no-implicit-dependencies
import { ApplicationStorageService } from 'src/app/core/ris/application-storage.service';
// tslint:disable-next-line: no-implicit-dependencies
import { UserService } from 'src/app/core/ris/user-service';

@Component({
    template: '<div>Please wait...</div>',
})
export class AuthenticationCallbackComponent implements OnInit {
    constructor(
        private adalService: AdalService,
        private applicationStorageService: ApplicationStorageService,
        private router: Router,
        private _zone: NgZone
    ) {}

    ngOnInit(): void {
        this.adalService.handleWindowCallback();
        if (this.adalService.userInfo.authenticated && window === window.parent) {
            let returnUrl: string = this.applicationStorageService.getObject('destinationUrl', true);
            if (!returnUrl) {
                returnUrl = 'home';
            }

            setTimeout(() => {
                this._zone
                    .run(() => this.router.navigateByUrl(returnUrl))
                    .then(() => this.applicationStorageService.deleteObject('destinationUrl', true));
            }, 10);
        }
    }
}
