import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { AdalService } from 'adal-angular4';
import { Observable } from 'rxjs';
// tslint:disable-next-line: no-duplicate-imports
import { of } from 'rxjs';
import { ApplicationStorageService } from '../../core/ris/application-storage.service';
import { UserService } from '../../core/ris/user-service';

@Injectable({
    providedIn: 'root',
})
export class AuthenticationGuard implements CanActivate {
    constructor(
        private adalService: AdalService,
        private userService: UserService,
        private applicationStorageService: ApplicationStorageService
    ) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
        if (this.userService.authenticated) {
            return of(true);
        } else {
            // write out destination url so that it can be read back after the authentication
            this.applicationStorageService.storeObject('destinationUrl', state.url, true);
            this.adalService.login();
            return of(false);
        }
    }
}
