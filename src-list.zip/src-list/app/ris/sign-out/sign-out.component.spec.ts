/* tslint:disable:no-unused-variable */
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { NovFooterComponent } from '../nov-footer/nov-footer.component';
import { SignOutComponent } from './sign-out.component';

describe('SignOutComponent', () => {
    let component: SignOutComponent;
    let fixture: ComponentFixture<SignOutComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SignOutComponent, NovFooterComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SignOutComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
