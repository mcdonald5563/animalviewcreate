import { Component, OnDestroy, OnInit } from '@angular/core';
import { UserService } from '../../core/ris/user-service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit, OnDestroy {
    constructor(public userService: UserService) {}
    ngOnInit() {
        this.userService.handleWindowCallback();
        if (this.userService.authenticated === false) {
            this.userService.login();
        }

        if (this.userService.authenticated && window === window.parent) {
            this.userService.initializeUser();
        }
    }
    login() {
        this.userService.login();
    }

    logout() {
        this.userService.logout();
    }

    get authenticated(): boolean {
        return this.userService.authenticated;
    }

    public ngOnDestroy() {
        this.userService.unsubscribe();
    }
}
