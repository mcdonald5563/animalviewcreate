/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbCollapseModule, NgbTab, NgbTabset } from '@ng-bootstrap/ng-bootstrap';
import { MenusComponent } from './menus.component';

describe('MenusComponent', () => {
    let component: MenusComponent;
    let fixture: ComponentFixture<MenusComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [NgbCollapseModule, RouterTestingModule],
            declarations: [MenusComponent, NgbTab, NgbTabset],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MenusComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
