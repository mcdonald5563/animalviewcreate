import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-styleguide',
    templateUrl: './styleguide.component.html',
    styleUrls: ['./styleguide.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class StyleguideComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
