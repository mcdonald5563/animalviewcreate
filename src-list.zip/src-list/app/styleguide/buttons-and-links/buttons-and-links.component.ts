import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-buttons-and-links',
    templateUrl: './buttons-and-links.component.html',
    styleUrls: ['./buttons-and-links.component.scss'],
})
export class ButtonsAndLinksComponent implements OnInit {
    isButtonDisabled: boolean;

    constructor() {
        this.isButtonDisabled = true;
    }

    ngOnInit() {}
}
