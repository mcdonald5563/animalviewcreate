import { Component, OnInit } from '@angular/core';
import { delay } from 'q';

class Animal {
    id?: number;
    species: string;
    class: string;
    lifeSpan: number;
}
// tslint:disable-next-line: max-classes-per-file
@Component({
    selector: 'app-loading-indicators',
    templateUrl: './loading-indicators.component.html',
    styleUrls: ['./loading-indicators.component.scss'],
})
export class LoadingIndicatorsComponent {
    public animals: Animal[] = [
        {
            id: 1,
            species: 'Blue Whale',
            class: 'Mammalia',
            lifeSpan: 110,
        },
        {
            id: 2,
            species: 'Giraffe',
            class: 'Mammalia',
            lifeSpan: 25,
        },
        {
            id: 3,
            species: 'Horse',
            class: 'Mammalia',
            lifeSpan: 35,
        },
        {
            id: 4,
            species: 'Cow',
            class: 'Mammalia',
            lifeSpan: 17,
        },
        {
            id: 5,
            species: 'Manatee',
            class: 'Mammalia',
            lifeSpan: 15,
        },
        {
            id: 6,
            species: 'Lion',
            class: 'Mammalia',
            lifeSpan: 20,
        },
        {
            id: 7,
            species: 'Ostrich',
            class: 'Aves',
            lifeSpan: 50,
        },
        {
            id: 8,
            species: 'Seal',
            class: 'Mammalia',
            lifeSpan: 13,
        },
        {
            id: 9,
            species: 'Hammerhead Shark',
            class: 'Chondrichthyes',
            lifeSpan: 18,
        },
        {
            id: 10,
            species: 'Goat',
            class: 'Mammalia',
            lifeSpan: 15,
        },
    ];
    isSaveButtonLoading: boolean;
    isGenerateReportButtonLoading: boolean;
    isLoadingOnforElements: boolean;
    isLoadingOnforReadOnlyData: boolean;
    selectedAnimal: string;

    constructor() {
        this.isSaveButtonLoading = false;
        this.isGenerateReportButtonLoading = false;
        this.isLoadingOnforElements = false;
    }

    public async clickTheSaveButton() {
        this.isSaveButtonLoading = true;
        await delay(3000);
        this.isSaveButtonLoading = false;
    }

    public async clickTheGenerateReportButton() {
        this.isGenerateReportButtonLoading = true;
        await delay(3000);
        this.isGenerateReportButtonLoading = false;
    }

    public toggleLoadingForFormElements() {
        this.isLoadingOnforElements = !this.isLoadingOnforElements;
    }

    public toggleLoadingForReadOnlyData() {
        this.isLoadingOnforReadOnlyData = !this.isLoadingOnforReadOnlyData;
    }
}
