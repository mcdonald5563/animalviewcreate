import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { NotFoundComponent } from '../ris/not-found/not-found.component';
import { AccordionsComponent } from './accordions/accordions.component';
import { AlertsComponent } from './alerts/alerts.component';
import { BadgesComponent } from './badges/badges.component';
import { ButtonsAndLinksComponent } from './buttons-and-links/buttons-and-links.component';
import { CardsComponent } from './cards/cards.component';
import { CollapseComponent } from './collapse/collapse.component';
import { DatesComponent } from './dates/dates.component';
import { DetailsPageComponent } from './details-page/details-page.component';
import { ErrorsComponent } from './errors/errors.component';
import { FormsComponent } from './forms/forms.component';
import { HttpResponsesComponent } from './http-responses/http-responses.component';
import { IconsComponent } from './icons/icons.component';
import { LoadingIndicatorsComponent } from './loading-indicators/loading-indicators.component';
import { LoginComponent } from './login/login.component';
import { MenusComponent } from './menus/menus.component';
import { ModalsComponent } from './modals/modals.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { OverviewComponent } from './overview/overview.component';
import { PageHeadersComponent } from './page-headers/page-headers.component';
import { PopoversAndTooltipsComponent } from './popovers-and-tooltips/popovers-and-tooltips.component';
import { StyleguideComponent } from './styleguide.component';
import { TablesComponent } from './tables/tables.component';
import { TabsComponent } from './tabs/tabs.component';
import { TypographyComponent } from './typography/typography.component';
import { InputGroupsComponent } from './input-groups/input-groups.component';
import { ChartsComponent } from './charts/charts.component';

const routes: Routes = [
    {
        path: '',
        redirectTo: 'overview',
        pathMatch: 'full',
    },
    {
        path: 'overview',
        component: OverviewComponent,
        data: { title: 'Overview' },
    },
    {
        path: 'Charts',
        component: ChartsComponent,
        data: { title: 'Charts' },
    },
    {
        path: 'accordions',
        component: AccordionsComponent,
        data: { title: 'Accordions' },
    },
    {
        path: 'badges',
        component: BadgesComponent,
        data: { title: 'Badges' },
    },
    {
        path: 'alerts',
        component: AlertsComponent,
        data: { title: 'Alerts' },
    },
    {
        path: 'buttonsandlinks',
        component: ButtonsAndLinksComponent,
        data: { title: 'Buttons and Links' },
    },
    {
        path: 'cards',
        component: CardsComponent,
        data: { title: 'Cards' },
    },
    {
        path: 'collapse',
        component: CollapseComponent,
        data: { title: 'Collapse' },
    },
    {
        path: 'dates',
        component: DatesComponent,
        data: { title: 'Dates' },
    },
    {
        path: 'details-page',
        component: DetailsPageComponent,
        data: { title: 'Details Page' },
    },
    {
        path: 'errors',
        component: ErrorsComponent,
        data: { title: 'Errors' },
    },
    {
        path: 'forms',
        component: FormsComponent,
        data: { title: 'Forms' },
    },
    {
        path: 'httpresponses',
        component: HttpResponsesComponent,
        data: { title: 'Http Responses' },
    },
    {
        path: 'icons',
        component: IconsComponent,
        data: { title: 'Icons' },
    },
    {
        path: 'input-groups',
        component: InputGroupsComponent,
        data: { title: 'Input Groups' },
    },
    {
        path: 'loadingindicators',
        component: LoadingIndicatorsComponent,
        data: { title: 'Loading Indicators' },
    },
    {
        path: 'login',
        component: LoginComponent,
        data: { title: 'Login' },
    },
    {
        path: 'menus',
        component: MenusComponent,
        data: { title: 'Menus' },
    },
    {
        path: 'modals',
        component: ModalsComponent,
        data: { title: 'Modals' },
    },
    {
        path: 'notifications',
        component: NotificationsComponent,
        data: { title: 'Notifications' },
    },
    {
        path: 'page-headers',
        component: PageHeadersComponent,
        data: { title: 'Page Headers' },
    },
    {
        path: 'popovers-and-tooltips',
        component: PopoversAndTooltipsComponent,
        data: { title: 'Popovers and ToolTips' },
    },
    {
        path: 'tabs',
        component: TabsComponent,
        data: { title: 'Tabs' },
    },
    {
        path: 'tables',
        component: TablesComponent,
        data: { title: 'Tables' },
    },
    {
        path: 'typography',
        component: TypographyComponent,
        data: { title: 'Typography' },
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class StyleguideRoutingModule {}
