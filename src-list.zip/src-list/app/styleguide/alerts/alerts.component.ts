import { Component, OnInit } from '@angular/core';
import { AlertifyService } from '../../core/ris/alertify.service';

@Component({
    selector: 'app-alerts',
    templateUrl: './alerts.component.html',
    styleUrls: ['./alerts.component.scss'],
})
export class AlertsComponent implements OnInit {
    isClosed: boolean;

    constructor(private alertifyService: AlertifyService) {}

    ngOnInit() {}

    public confirmSuccess() {
        this.alertifyService.success('Example created successfully', 'Success Test');
    }
}
