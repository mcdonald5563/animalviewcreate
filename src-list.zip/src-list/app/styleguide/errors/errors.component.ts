import { Component, OnInit } from '@angular/core';
import { AlertifyService } from '../../core/ris/alertify.service';
import { ErrorSeverity } from '../../core/ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../../core/ris/error-log.service';

@Component({
    selector: 'app-errors',
    templateUrl: './errors.component.html',
    styleUrls: ['./errors.component.scss'],
})
export class ErrorsComponent {
    constructor(private errorLogService: ErrorLogService, private alertifyService: AlertifyService) {}

    public logError() {
        this.errorLogService.logError('Archetype test error', ErrorSeverity.warning);
        this.alertifyService.success('Error sent', 'Error Test');
    }
}
