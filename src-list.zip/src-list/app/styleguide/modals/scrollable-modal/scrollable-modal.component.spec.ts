/* tslint:disable:no-unused-variable */
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ScrollableModalComponent } from './scrollable-modal.component';

describe('ScrollableModalComponent', () => {
    let component: ScrollableModalComponent;
    let fixture: ComponentFixture<ScrollableModalComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [NgbActiveModal],
            declarations: [ScrollableModalComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ScrollableModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
