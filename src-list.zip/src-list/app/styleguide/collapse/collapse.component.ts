import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-collapse',
    templateUrl: './collapse.component.html',
    styleUrls: ['./collapse.component.scss'],
})
export class CollapseComponent implements OnInit {
    public isStandardExampleCollapsed: boolean;
    public isIconTextChangeExampleCollapsed: boolean;
    public isTableCollapsed: boolean;
    public isTextCollapsed: boolean;

    constructor() {
        this.isStandardExampleCollapsed = true;
        this.isIconTextChangeExampleCollapsed = true;
        this.isTableCollapsed = true;
        this.isTextCollapsed = true;
    }

    ngOnInit() {}
}
