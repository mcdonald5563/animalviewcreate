import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-popovers-and-tooltips',
    templateUrl: './popovers-and-tooltips.component.html',
    styleUrls: ['./popovers-and-tooltips.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class PopoversAndTooltipsComponent implements OnInit {
    exampleBinding: string;
    constructor() {
        this.exampleBinding = 'an example Angular binding';
    }

    ngOnInit() {}
}
