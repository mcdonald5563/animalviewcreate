import { Component, OnInit } from '@angular/core';
import { ChartViewModel } from './chart.viewmodel';

@Component({
    selector: 'app-charts',
    templateUrl: './charts.component.html',
    styleUrls: ['./charts.component.scss'],
})
export class ChartsComponent implements OnInit {
    pieChartViewModel: ChartViewModel;
    constructor() {
        this.pieChartViewModel = new ChartViewModel();
        this.pieChartViewModel.chartConfig = {
            width: '100%',
            height: '400',
            type: 'pie2d',
            dataFormat: 'json',
        };
        this.setupFusionCharts();
    }

    ngOnInit() {}

    setupFusionCharts(): void {
        this.pieChartViewModel.chartDataSource = {
            chart: {
                caption: 'Period Analytics',
                subcaption: `sub-caption label`,
                numbersuffix: '%',
                theme: 'fusion',
            },
            data: [
                {
                    label: 'Label 1',
                    value: 12,
                },
                {
                    label: 'Label 2',
                    value: 12,
                },
                {
                    label: 'Label 3',
                    value: 12,
                },
            ],
        };
    }
}
