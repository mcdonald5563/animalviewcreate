/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NgbDate, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DatesComponent } from './dates.component';

describe('DatesComponent', () => {
    let component: DatesComponent;
    let fixture: ComponentFixture<DatesComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [FormsModule, NgbModule],
            declarations: [DatesComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DatesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should set date range correctly', () => {
        // Arrange
        component.onDateSelection(new NgbDate(2019, 1, 1));
        component.onDateSelection(new NgbDate(2019, 1, 2));

        // Act

        // Assert
        expect(component.fromDate.before(component.toDate)).toBeTruthy();
    });

    it('should reset dates when checkDateRange() is called', () => {
        // Arrange
        component.toDate = null;
        component.fromDate = new NgbDate(2019, 1, 1);

        // Act
        component.checkDateRange();

        // Assert
        expect(component.fromDate).toBeNull();
    });

    it('should return true when isHovered() is called', () => {
        // Arrange
        component.fromDate = new NgbDate(2019, 1, 1);
        component.toDate = null;
        component.hoveredDate = new NgbDate(2019, 1, 5);

        // Act
        const hovered = component.isHovered(new NgbDate(2019, 1, 3));

        // Assert
        expect(hovered).toBeTruthy();
    });

    it('should return true when isInside() is called', () => {
        // Arrange
        component.fromDate = new NgbDate(2019, 1, 1);
        component.toDate = new NgbDate(2019, 1, 3);

        // Act
        const inside = component.isInside(new NgbDate(2019, 1, 2));

        // Assert
        expect(inside).toBeTruthy();
    });

    it('should return true when isRange() is called', () => {
        // Arrange
        component.fromDate = new NgbDate(2019, 1, 1);

        // Act
        const isrange = component.isRange(new NgbDate(2019, 1, 1));

        // Assert
        expect(isrange).toBeTruthy();
    });
});
