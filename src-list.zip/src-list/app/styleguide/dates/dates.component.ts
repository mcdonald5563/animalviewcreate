import { Component, OnInit } from '@angular/core';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { DateRangeFormatPipe } from '../../shared/pipes/date/date-range.pipe';

@Component({
    selector: 'app-dates',
    templateUrl: './dates.component.html',
    styleUrls: ['./dates.component.scss'],
    providers: [DateRangeFormatPipe],
})
export class DatesComponent implements OnInit {
    hoveredDate: NgbDate;
    fromDate: NgbDate;
    toDate: NgbDate;
    dateRange: string;
    selectedDate: NgbDate;

    constructor(private dateRangeFormatPipe: DateRangeFormatPipe) {}

    onDateSelection(date: NgbDate) {
        if (!this.fromDate && !this.toDate) {
            this.fromDate = date;
        } else if (this.fromDate && !this.toDate && (date.after(this.fromDate) || date.equals(this.fromDate))) {
            this.toDate = date;
            const start = new Date(this.fromDate.year, this.fromDate.month - 1, this.fromDate.day);
            const end = new Date(date.year, date.month - 1, date.day);
            this.dateRange = this.dateRangeFormatPipe.transform(start, end);
        } else {
            this.toDate = null;
            this.fromDate = date;
        }
    }

    isHovered(date: NgbDate) {
        return this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate);
    }

    isInside(date: NgbDate) {
        return date.after(this.fromDate) && date.before(this.toDate);
    }

    isRange(date: NgbDate) {
        return date.equals(this.fromDate) || date.equals(this.toDate) || this.isInside(date) || this.isHovered(date);
    }

    checkDateRange() {
        if (this.toDate === null) {
            this.fromDate = null;
            this.toDate = null;
        }
    }

    clearSelectedDate() {
        this.selectedDate = null;
    }

    ngOnInit() {}
}
