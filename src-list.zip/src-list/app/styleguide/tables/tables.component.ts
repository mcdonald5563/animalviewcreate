import { Component, OnInit } from '@angular/core';
import { AnimalResponse } from '../../core/models/animal-response.model';
import { AnimalsResponse } from '../../core/models/animals-response-model';
import { ErrorResponse } from '../../core/ris/error-response';
import { AnimalService } from '../../core/services/animal.service';

@Component({
    selector: 'app-tables',
    templateUrl: './tables.component.html',
    styleUrls: ['./tables.component.scss'],
})
export class TablesComponent implements OnInit {
    public animals: AnimalResponse[];
    public page = 1;
    public pageSize = 10;
    public totalResultCount = 0;
    public isTableSmClassApplied = false;
    public IsLoadingAnimals: boolean;
    constructor(private animalService: AnimalService) {
        this.IsLoadingAnimals = true;
    }

    ngOnInit() {
        this.animalService.getAnimals(null).subscribe(
            (data: AnimalsResponse) => {
                this.animals = data.animals;
                this.totalResultCount = this.animals.length;
                this.IsLoadingAnimals = false;
            },
            (err: ErrorResponse) => '',
            () => ''
        );
    }

    checkAll(isChecked: boolean) {
        this.animals.forEach((x) => (x.selected = isChecked));
    }
}
