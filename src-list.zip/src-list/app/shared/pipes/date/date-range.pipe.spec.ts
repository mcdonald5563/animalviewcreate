/* tslint:disable:no-unused-variable */

import { async, TestBed } from '@angular/core/testing';
import { DateRangeFormatPipe } from './date-range.pipe';

describe('Pipe: Datee', () => {
    it('create an instance', () => {
        const pipe = new DateRangeFormatPipe('');
        expect(pipe).toBeTruthy();
    });
});
