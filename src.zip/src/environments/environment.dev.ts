// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    applicationId: 80,
    applicationName: 'Archetype SPA',
    azureConfig: {
        tenant: '5ebe82bb-f23f-4bb6-b7d0-b038c066ad05',
        clientId: 'b66ddbb5-f7a7-4597-af9d-ee2cd8e91fab',
        redirectUri: 'https://archetypedev.nov.cloud/oauth2-callback',
        cacheLocation: 'localStorage',
        endpoints: {
            'https://graph.microsoft.com': '00000003-0000-0000-c000-000000000000',
            'https://rispersonservicedev.nov.cloud': 'https://nov.onmicrosoft.com/RigIsPersonService',
            'https://risarchetypedev.nov.cloud': 'https://nov.onmicrosoft.com/RigIs-Archetype-Service',
            'https://riserrorservicedev.nov.cloud': 'https://nov.onmicrosoft.com/RigIsErrorService',
            'https://risApplicationSecurityServiceDev.nov.cloud': 'https://nov.onmicrosoft.com/RigIs-ApplicationSecurity-Service',
        },
    },
    endpoints: {
        archetypeServiceUrl: 'https://risarchetypedev.nov.cloud/api/v1',
        errorServiceUrl: 'https://riserrorservicedev.nov.cloud/api/v1',
        applicationSecurityServiceUrl: 'https://risApplicationSecurityServiceDev.nov.cloud/api/v1',
    },
    referenceUrls: {
        archetypeWiki: 'https://wiki.nov.com/display/RSIS/Archetype',
        defaultUserPhotoUrl: `data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjwhRE9DVFlQRSBzdmc
  gIFBVQkxJQyAnLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4nICAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEu
  MS9EVEQvc3ZnMTEuZHRkJz48c3ZnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDUxMiA1MTIiIGhlaWdodD0iNTEyc
  HgiIGlkPSJMYXllcl8xIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA1MTIgNTEyIiB3aWR0aD0iNTEycHgiIHhtbD
  pzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA
  6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxwYXRoIGQ9Ik0yNTcuMTA3LDVDMTE4LjQ3Myw1LDYuMTA5LDExNy4zNjUs
  Ni4xMDksMjU1Ljk5OEM2LjEwOSwzOTQuNjMxLDExOC40NzMsNTA3LDI1Ny4xMDcsNTA3ICBzMjUwLjk5OC0xMTIuMzcsM
  jUwLjk5OC0yNTEuMDAyQzUwOC4xMDUsMTE3LjM2NSwzOTUuNzQsNSwyNTcuMTA3LDV6IE0yNTcuMTA3LDI1LjkxN2MxMj
  YuODY4LDAsMjMwLjA4MiwxMDMuMjE0LDIzMC4wODIsMjMwLjA4MiAgYzAsNTUuODE1LTE5Ljk5NywxMDcuMDQzLTUzLjE
  5LDE0Ni45MjZjLTIyLjkzOS05LjU4LTc3LjA4OS0yOC4zNzItMTEwLjYwOS0zOC4yNjljLTIuODU5LTAuODk4LTMuMzA5
  LTEuMDQyLTMuMzA5LTEyLjk0ICBjMC05LjgyNiw0LjA0NC0xOS43MjEsNy45ODctMjguMDk2YzQuMjY5LTkuMSw5LjMzN
  C0yNC4zOTksMTEuMTUzLTM4LjEyNmM1LjA4Ni01LjkwNCwxMi4wMS0xNy41NDcsMTYuNDYzLTM5LjczOSAgYzMuOTAxLT
  E5LjU1OSwyLjA4My0yNi42NzctMC41MS0zMy4zNTdjLTAuMjY2LTAuNzA1LTAuNTUyLTEuMzk5LTAuNzU2LTIuMDk0Yy0
  wLjk4MS00LjU4NiwwLjM2Ny0yOC40MTMsMy43MTgtNDYuODk5ICBjMi4zMDgtMTIuNjg1LTAuNTkzLTM5LjY1OC0xOC4w
  NTctNjEuOTcyYy0xMS4wMy0xNC4xMDUtMzIuMTMxLTMxLjQxNi03MC42NzUtMzMuODI2bC0yMS4xNDEsMC4wMiAgYy0zN
  y44OTEsMi4zOTEtNTkuMDEyLDE5LjcwMS03MC4wNDIsMzMuODA2Yy0xNy40NjQsMjIuMzE1LTIwLjM2NCw0OS4yODgtMT
  guMDU2LDYxLjk2M2MzLjM3LDE4LjQ5NSw0LjY5OCw0Mi4zMjIsMy43MzgsNDYuODE2ICBjLTAuMjA0LDAuNzg2LTAuNDk
  sMS40ODEtMC43NzYsMi4xODZjLTIuNTc0LDYuNjgtNC40MTIsMTMuNzk4LTAuNDksMzMuMzU3YzQuNDMyLDIyLjE5Miwx
  MS4zNTcsMzMuODM2LDE2LjQ2MywzOS43MzkgIGMxLjc5OCwxMy43MjYsNi44NjQsMjkuMDI2LDExLjE1MywzOC4xMjZjM
  y4xMjUsNi42NTksNC41OTYsMTUuNzE4LDQuNTk2LDI4LjUyNWMwLDExLjg5OC0wLjQ1LDEyLjA0Mi0zLjEyNiwxMi44OD
  kgIGMtMzQuNjYzLDEwLjIzNC04OS44MzQsMzAuMTctMTEwLjQwNCwzOS4xNzhjLTMzLjg0Ni00MC4wNjYtNTQuMjkzLTk
  xLjc4NS01NC4yOTMtMTQ4LjIxMiAgQzI3LjAyNSwxMjkuMTMsMTMwLjIzOSwyNS45MTcsMjU3LjEwNywyNS45MTd6IE05
  Ni40NzQsNDIwLjUxNmMyMy41NTItOS42MTUsNzAuNTEyLTI2LjM2NSwxMDEuMzU1LTM1LjQ3NSAgYzE3LjkzNS01LjY1O
  CwxNy45MzUtMjAuNzYzLDE3LjkzNS0zMi44OTZjMC0xMC4wNi0wLjY5NC0yNC44OS02LjU3Ny0zNy40MzFjLTQuMDQ1LT
  guNTg5LTguNjYyLTIzLjMxNy05LjY4Mi0zNC44NDcgIGMtMC4yMjUtMi42OTYtMS40OTEtNS4xODgtMy41MzQtNi45NjV
  jLTIuOTYyLTIuNTk1LTguOTg4LTEyLjA5My0xMi44MjgtMzEuMjUyYy0zLjA0My0xNS4xNjctMS43NTYtMTguNDg2LTAu
  NTEtMjEuNjkzICBjMC41MzEtMS4zNjksMS4wNDItMi43MTcsMS40NTEtNC4yMzljMi41MTItOS4xODEtMC4yODctMzkuM
  zQxLTMuMzMtNTYuMDdjLTEuMzI3LTcuMjcyLDAuMzQ3LTI3LjkzMywxMy45NTEtNDUuMzM3ICBjMTIuMTk0LTE1LjU5NS
  wzMC42NTktMjQuMjg3LDU0LjIxMS0yNS43ODhsMTkuODM0LTAuMDIxYzI0LjE4NSwxLjUyMiw0Mi42NSwxMC4yMTQsNTQ
  uODY1LDI1LjgwOSAgYzEzLjYwNCwxNy40MDQsMTUuMjU5LDM4LjA2NSwxMy45Myw0NS4zNDZjLTMuMDIzLDE2LjcyLTUu
  ODQyLDQ2Ljg3OS0zLjMzLDU2LjA1YzAuNDMsMS41MzIsMC45MTksMi44OCwxLjQ1MSw0LjI0OSAgYzEuMjQ3LDMuMjA2L
  DIuNTMzLDYuNTI2LTAuNDksMjEuNjkzYy0zLjgzOSwxOS4xNi05Ljg4NiwyOC42NTgtMTIuODQ4LDMxLjI1MmMtMi4wMj
  IsMS43NzctMy4yODgsNC4yNjktMy41MzQsNi45NjUgIGMtMS4wMDEsMTEuNTMtNS42MTcsMjYuMjU4LTkuNjYxLDM0Ljg
  0N2MtNC42MzcsOS44NTYtOS45NjgsMjIuOTgtOS45NjgsMzcuMDAyYzAsMTIuMTM0LDAsMjcuMjM5LDE4LjExOCwzMi45
  NDggIGMyOS41MTYsOC43MjIsNzYuNzAxLDI0LjkzLDEwMS42MjEsMzQuNzNjLTQxLjYwOCw0MS4xOTktOTguNzgxLDY2L
  jY5MS0xNjEuNzk3LDY2LjY5MSAgQzE5NC42NjQsNDg2LjA4NCwxMzcuOTgxLDQ2MS4wNDIsOTYuNDc0LDQyMC41MTZ6Ii
  BmaWxsPSIjMzc0MDREIi8+PC9zdmc+`,
    },
};
