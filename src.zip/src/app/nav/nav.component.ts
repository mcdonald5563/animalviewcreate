import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../core/ris/security.service';

@Component({
    selector: 'app-nav',
    templateUrl: './nav.component.html',
    styleUrls: ['./nav.component.scss'],
})
export class NavComponent implements OnInit {
    isNavbarCollapsed: boolean;

    constructor(private securityService: SecurityService) {
        this.isNavbarCollapsed = true;
    }

    ngOnInit() {}

    public canViewAnimal(): boolean {
        let canViewAnimal = true;

        // if (this.securityService.userSecurityInfo !== undefined && this.securityService.userSecurityInfo !== null) {
        //     canViewAnimal = this.securityService.isPermitted('ARCHETYPE_ANIMAL_VIEW');
        // }
        return canViewAnimal;
    }
}
