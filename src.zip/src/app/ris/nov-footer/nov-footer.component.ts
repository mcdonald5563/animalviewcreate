import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-nov-footer',
    templateUrl: './nov-footer.component.html',
    styleUrls: ['./nov-footer.component.scss'],
})
export class NovFooterComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
