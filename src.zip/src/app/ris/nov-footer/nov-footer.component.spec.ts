/* tslint:disable:no-unused-variable */
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { NovFooterComponent } from './nov-footer.component';

describe('NovFooterComponent', () => {
    let component: NovFooterComponent;
    let fixture: ComponentFixture<NovFooterComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [NovFooterComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NovFooterComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
