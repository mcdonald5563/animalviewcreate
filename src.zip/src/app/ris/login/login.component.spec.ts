/* tslint:disable:no-unused-variable */
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AdalService } from 'adal-angular4';
import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
    let component: LoginComponent;
    let fixture: ComponentFixture<LoginComponent>;
    let mockAdalService: AdalService;

    beforeEach(async(() => {
        mockAdalService = jasmine.createSpyObj(['handleWindowCallback', 'userInfo', 'login', 'logOut']);

        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            declarations: [LoginComponent],
            providers: [{ provide: AdalService, useValue: mockAdalService }],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LoginComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should call login method of AdalService', () => {
        component.login();
        expect(mockAdalService.login).toHaveBeenCalled();
    });

    it('should call logout method of AdalService', () => {
        component.logout();
        expect(mockAdalService.logOut).toHaveBeenCalled();
    });
});
