import { Injectable } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ApiLoginService {
    API_URL="https://risapplicationsecurityservicedev.nov.cloud/api/v1/Login";
     constructor(private httpClient: HttpClient) { }
  


getLoginName(id:number){
  return this.httpClient.get(this.API_URL + "/" + id);
}
}
