import { Injectable } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ApiAnimalServiceService {
    API_URL="https://risarchetypedev.nov.cloud/api/v1/Animals";
     constructor(private httpClient: HttpClient) { }
  
//   getAnimals(){
//     return this.httpClient.get(this.API_URL);
// }

public getAnimals(): Observable<animal[]> {
  return this.httpClient.get<animal[]>(this.API_URL)
}

getAnimal(id:number){
  return this.httpClient.get(this.API_URL + "/" + id);
}

addAnimal(animal:any){
  return this.httpClient.post(this.API_URL, animal);
}
}
export class animal {
  id:0;
  name:"";
  description:"";
  averageLifeSpan:"";
  classificationId:"";
  discoveredDate:"";
  nextFeedDateTime:"";
};
