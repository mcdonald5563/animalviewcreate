import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'dateRangeFormat',
})
export class DateRangeFormatPipe extends DatePipe implements PipeTransform {
    transform(startdate: any, endDate: any, args?: any): any {
        const to = super.transform(startdate.toLocaleString(), 'dd-MMM-yyyy');
        const from = super.transform(endDate.toLocaleString(), 'dd-MMM-yyyy');
        return `${to}  to  ${from}`;
    }
}
