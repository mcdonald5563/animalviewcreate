import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DateRangeFormatPipe } from './pipes/date/date-range.pipe';

@NgModule({
    imports: [CommonModule, FormsModule],
    declarations: [DateRangeFormatPipe],
    exports: [CommonModule, DateRangeFormatPipe],
})
export class SharedModule {}
