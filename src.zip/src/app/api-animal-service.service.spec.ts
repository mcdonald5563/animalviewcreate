import { TestBed } from '@angular/core/testing';

import { ApiAnimalServiceService } from './api-animal-service.service';

describe('ApiAnimalServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ApiAnimalServiceService = TestBed.get(ApiAnimalServiceService);
    expect(service).toBeTruthy();
  });
});
