import { TestBed } from '@angular/core/testing';

import { AnimalCreateService } from './animal-create.service';

describe('AnimalCreateService', () => {
    beforeEach(() => TestBed.configureTestingModule({}));

    it('should be created', () => {
        const service: AnimalCreateService = TestBed.get(AnimalCreateService);
        expect(service).toBeTruthy();
    });
});
