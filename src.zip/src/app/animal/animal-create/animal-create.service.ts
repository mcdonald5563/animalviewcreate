import { Injectable } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
    providedIn: 'root',
})
export class AnimalCreateService implements OnInit {
    ngOnInit(): void {
    }
    API_URL="http://localhost:52205/api/animal";
    constructor(private httpClient: HttpClient) { }
    addAnimal(animal:any){
        return this.httpClient.post(this.API_URL, animal);
      }
}
