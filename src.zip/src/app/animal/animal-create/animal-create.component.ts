import { Component, OnInit } from '@angular/core';
import { AnimalCreateService } from './animal-create.service';
import { Router} from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
@Component({
    selector: 'app-animal-create',
    templateUrl: './animal-create.component.html',
    styleUrls: ['./animal-create.component.scss']  
   
})
export class AnimalCreateComponent implements OnInit {
    hoveredDate: NgbDate;
    animal={
        name:"",
        description:"",
        classificationId:"",
        averageLifeSpan:"",
        discoveredDate: "",
        nextFeedDateTime: ""
      } 
  public classifications: any[] = [
    {
        id: 1,
        species: 'classification 1',
        class: 'Mammalia',
        lifeSpan: 110,
    },
    {
        id: 2,
        species: 'classification 2',
        class: 'Mammalia',
        lifeSpan: 25,
    },    
];
 
    constructor(private formBuilder: FormBuilder, private animalCreateService: AnimalCreateService, 
        private router : Router) {
            
    }
    
    meridian = true;
    ngOnInit() {}
    onSubmit() {       
    
        this.animalCreateService.addAnimal(this.animal).subscribe((res:any)=>{
         this.router.navigate(['/animal']);
        })
    }   
    

   
}