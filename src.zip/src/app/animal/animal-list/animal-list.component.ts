import { Component, OnInit } from '@angular/core';
import {ApiAnimalServiceService,animal } from '../../api-animal-service.service';


@Component({
  selector: 'app-animal-list',
  templateUrl: './animal-list.component.html',
  styleUrls: ['./animal-list.component.scss']
})
export class AnimalListComponent implements OnInit {
  

  animals:animal[];
  constructor(private apiAnimalServiceService: ApiAnimalServiceService) { }
  
  ngOnInit(): void {
    this.apiAnimalServiceService.getAnimals().subscribe((res:animal[])=>{         
      this.animals = res;      
    })
  }
}
