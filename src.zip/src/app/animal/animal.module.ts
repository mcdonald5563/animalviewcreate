import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnimalCreateComponent } from './animal-create/animal-create.component';
import { AnimalListComponent } from './animal-list/animal-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AnimalViewComponent } from './animal-view/animal-view.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbDatePickerParserFormatterService } from '../core/ris/ngbdatepicker-parser-formatter.service';
import { AdalInterceptor, AdalService } from 'adal-angular4';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { NgbDate, NgbModule } from '@ng-bootstrap/ng-bootstrap';
 
@NgModule({
    declarations: [AnimalCreateComponent, AnimalListComponent, AnimalViewComponent],
    imports: [NgbModule,CommonModule, RouterModule,FormsModule, ReactiveFormsModule , NgSelectModule],
    providers: [
        AdalService,
        { provide: HTTP_INTERCEPTORS, useClass: AdalInterceptor, multi: true },
        { provide: NgbDateParserFormatter, useFactory: () => new NgbDatePickerParserFormatterService() },
    ],
})
export class AnimalModule {}