import { Component, OnInit } from '@angular/core';
import {ApiAnimalServiceService } from '../../api-animal-service.service';
import { ApiLoginService } from '../../api-login-service.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-animal-view',
  templateUrl: './animal-view.component.html',
  styleUrls: ['./animal-view.component.scss']
})
export class AnimalViewComponent implements OnInit {
  animal = {
    name:"",
    description:"",
    averageLifeSpan:"",
    classificationId:"",
    discoveredDate:"",
    nextFeedDateTime:"",
    createdByLoginId:0,
    updatedByLoginId:0,
    createdByLoginName:"",
    updatedByLoginName:"",
    createdDateTime:"",
    updatedDateTime:""
  };
  loginName = {
    name : ""
  }
  constructor(private apiAnimalServiceService: ApiAnimalServiceService,private apiLoginService: ApiLoginService,private router : Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let id= this.activatedRoute.snapshot.params["id"];
    this.apiAnimalServiceService.getAnimal(id).subscribe((res:any)=>{
      this.animal = res;
      this.apiLoginService.getLoginName(this.animal.createdByLoginId).subscribe((res:any)=>{
        this.loginName=res;
        this.animal.createdByLoginName = this.loginName.name;
      })
      this.apiLoginService.getLoginName(this.animal.updatedByLoginId).subscribe((res:any)=>{
        this.loginName=res;
        this.animal.updatedByLoginName = this.loginName.name;
      })
    })
  }

}
