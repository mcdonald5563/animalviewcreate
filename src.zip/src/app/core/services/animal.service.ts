import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AnimalsResponse } from '../models/animals-response-model';
import { ErrorSeverity } from '../ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../ris/error-log.service';
import { ErrorResponse } from '../ris/error-response';

export interface IAnimalService {
    getAnimals(animalsListProfile: any): Observable<AnimalsResponse | ErrorResponse>;
}

@Injectable({
    providedIn: 'root',
})
export class AnimalService implements IAnimalService {
    constructor(private http: HttpClient, private errorLogService: ErrorLogService) {}

    public getAnimals(animalsListProfile: any): Observable<AnimalsResponse | ErrorResponse> {
        const url = `${environment.endpoints.archetypeServiceUrl}/Animals`;
        const params = animalsListProfile;
        return this.http
            .get<AnimalsResponse>(url, { params })
            .pipe(catchError((err) => this.errorLogService.handleHttpError(err, ErrorSeverity.critical)));
    }
}
