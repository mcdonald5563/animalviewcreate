export class AnimalResponse {
    id: number;
    name: string;
    description: string;
    averageLifespan: number;
    classificationId: number;
    classificationLink: string;
    discoverDate: Date;
    selected: boolean;
}
