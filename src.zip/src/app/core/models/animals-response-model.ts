import { AnimalResponse } from './animal-response.model';

export class AnimalsResponse {
    public animals: AnimalResponse[];
    public totalResultCount: number;
}
