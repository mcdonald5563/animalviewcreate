export class AnimalListProfile {
    public keyword: string;
}
