import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface IHttpGetRequestClient {
    getHttpRequest<T>(url: string): Observable<T>;
}

@Injectable({
    providedIn: 'root',
})
export class HttpGetRequestClient implements IHttpGetRequestClient {
    constructor(private http: HttpClient) {}

    public getHttpRequest<T>(url: string): Observable<T> {
        return this.http.get<T>(url).pipe(
            map((data: T) => {
                return data;
            }),
            catchError(this.handleError)
        );
    }

    private handleError(error: Response) {
        const msg = `Error status code ${error.status} at ${error.url}`;
        return throwError(msg);
    }
}
