import { SafeUrl } from '@angular/platform-browser';

export class User {
    username: string;
    firstName: string;
    lastName: string;
    photo: any;
    photoUrl: SafeUrl;
    oid: any;
}
