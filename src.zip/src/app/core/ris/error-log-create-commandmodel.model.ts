export enum ErrorSeverity {
    warning = 1,
    critical = 2,
}
export class ErrorLogCreateCommandModel {
    public message: string;
    callStack: string;
    applicationId: number;
    severity: ErrorSeverity;
    exceptionMessage: string;
}
