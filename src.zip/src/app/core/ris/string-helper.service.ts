import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class StringHelperService {
    constructor() {}

    public truncatePrefix(value: string, separator: string): string {
        if (value.includes(separator) === true) {
            value = value.split(separator)[1];
        }
        return value;
    }
}
