import { DatePipe } from '@angular/common';
import { NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

export class NgbDatePickerParserFormatterService extends NgbDateParserFormatter {
    datePipe = new DatePipe('en-US');
    dateFormat = 'dd-MMM-yyyy';

    constructor() {
        super();
    }

    format(date: NgbDateStruct): string {
        return date !== null && date !== undefined && isNaN(date.day) !== true && isNaN(date.month) !== true && isNaN(date.year) !== true
            ? this.datePipe.transform(new Date(date.year, date.month - 1, date.day), this.dateFormat)
            : null;
    }

    parse(value: string): NgbDateStruct {
        {
            if (value === null || value === undefined || value.length === 0) {
                return null;
            }
            const splitDate = value.split('-');
            if (splitDate.length === 3) {
                const dateParts = this.datePipe.transform(value, 'M-d-y').split('-');
                // tslint:disable-next-line: radix
                return { year: parseInt(dateParts[2]), month: parseInt(dateParts[0]), day: parseInt(dateParts[1]) };
            }
        }
    }
}
