import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { UserSecurityInfo } from './models/user-security-info.model';

@Injectable({
    providedIn: 'root',
})
export class SecurityService {
    public userSecurityInfo: UserSecurityInfo;

    constructor(private http: HttpClient) {}

    public getUserSecurityInfo(): Observable<UserSecurityInfo | null> {
        const authorizeCommand: any = {
            applicationId: environment.applicationId,
        };
        const headers = new HttpHeaders({ 'Context-Type': 'application/json' });
        const applicationSecurityServiceUrl = `${environment.endpoints.applicationSecurityServiceUrl}/Authorize/Validate`;
        return this.http
            .post<UserSecurityInfo>(applicationSecurityServiceUrl, authorizeCommand, { headers })
            .pipe(
                map((data: UserSecurityInfo) => {
                    return data;
                }),
                catchError(this.handleError)
            );
    }

    public isPermitted(permissionCode: any, inventoryOrgId?: number): boolean {
        if (Array.isArray(permissionCode) === true) {
            return this.isPermittedOr(permissionCode, inventoryOrgId);
        }

        if (typeof permissionCode !== 'string' && permissionCode instanceof String === false) {
            throwError('invalid input argument to securityService.isPermitted()');
        }

        return this.userSecurityInfo.authorizedPermissions.some((x) =>
            inventoryOrgId == null
                ? x.permissionCode.toUpperCase() === permissionCode.toUpperCase()
                : x.permissionCode.toUpperCase() === permissionCode.toUpperCase() && x.inventoryOrgId === inventoryOrgId
        );
    }

    private isPermittedOr(permissionCodes: string[], inventoryOrgId?: number): boolean {
        return permissionCodes.some((permissionCode) =>
            this.userSecurityInfo.authorizedPermissions.some((x) =>
                inventoryOrgId == null
                    ? x.permissionCode.toUpperCase() === permissionCode.toUpperCase()
                    : x.permissionCode.toUpperCase() === permissionCode.toUpperCase() && x.inventoryOrgId === inventoryOrgId
            )
        );
    }

    private handleError(error: Response) {
        return throwError(`Error status code ${error.status} at ${error.url}`);
    }
}
