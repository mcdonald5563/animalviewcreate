import { HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ErrorSeverity } from './error-log-create-commandmodel.model';
import { ErrorLogService } from './error-log.service';
import { ErrorResponse } from './error-response';

describe('Service: ErrorLog', () => {
    let http: HttpTestingController;
    let service: ErrorLogService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [ErrorLogService],
        });
        service = TestBed.get(ErrorLogService);
        http = TestBed.get(HttpTestingController);
    });

    it('should create an instance', () => {
        expect(service).toBeDefined();
    });

    it('should call correct post url', () => {
        // Arrange
        const url = `${environment.endpoints.errorServiceUrl}/ErrorLogs`;

        // Act
        service.logError('test message', ErrorSeverity.critical);
        http.expectOne({ url, method: 'POST' });
    });
});
