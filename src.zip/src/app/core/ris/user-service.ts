import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { AdalService } from 'adal-angular4';
import { environment } from '../../../environments/environment';
import { SecurityService } from './security.service';
import { User } from './user-model';

@Injectable({
    providedIn: 'root',
})
export class UserService {
    public user: User;
    private securitySubscribe;
    private photoSubscribe;

    constructor(
        protected http: HttpClient,
        private domSanitizer: DomSanitizer,
        private adalService: AdalService,
        private securityService: SecurityService
    ) {
        this.user = new User();
        this.user.photoUrl = this.domSanitizer.bypassSecurityTrustUrl(environment.referenceUrls.defaultUserPhotoUrl);
    }

    public login() {
        this.adalService.login();
    }

    public handleWindowCallback() {
        this.adalService.handleWindowCallback();
    }

    public init() {
        this.adalService.init(environment.azureConfig);
    }

    public logout() {
        this.adalService.logOut();
    }
    public get authenticated(): boolean {
        return this.adalService.userInfo.authenticated;
    }
    public initializeUser() {
        this.securitySubscribe = this.securityService.getUserSecurityInfo().subscribe((usersecurityinfo) => {
            if (usersecurityinfo !== null) {
                this.securityService.userSecurityInfo = usersecurityinfo;
            }
        });
        this.photoSubscribe = this.getPhoto().subscribe({
            next: (result) => {
                this.user.photo = result;
                this.constructPhotoUrl(this.user.photo);
                this.photoSubscribe.unsubscribe();
            },
        });
        this.adalService.getUser().subscribe((user: adal.User) => {
            if (user !== null) {
                this.user.username = user.userName;
                this.user.firstName = user.profile.given_name;
                this.user.lastName = user.profile.family_name;
                this.user.oid = user.profile.oid;
            }
        });
    }

    public getPhoto() {
        const headers = new HttpHeaders({
            Accept: 'image/jpeg',
            'Content-Type': 'image/jpeg',
        });

        const options: object = {
            headers,
            responseType: 'blob',
        };
        return this.http.get('https://graph.microsoft.com/v1.0/me/photo/$value', options);
    }

    private constructPhotoUrl(photo: Blob) {
        let base64data: any;

        if (typeof photo !== 'undefined') {
            const reader = new FileReader();
            reader.readAsDataURL(photo);
            reader.onloadend = () => {
                base64data = reader.result;
                this.user.photoUrl = this.domSanitizer.bypassSecurityTrustUrl(base64data);
            };
        } else {
            console.log('photo is undefined');
            return null;
        }
    }

    public unsubscribe() {
        this.photoSubscribe.unsubscribe();
        this.securitySubscribe.unsubscribe();
    }
}
