import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ErrorLogCreateCommandModel, ErrorSeverity } from './error-log-create-commandmodel.model';
import { ErrorResponse } from './error-response';

@Injectable({
    providedIn: 'root',
})
export class ErrorLogService {
    constructor(private http: HttpClient) {}

    public logError(message: string, severity: ErrorSeverity) {
        const errorLogCreateCommandModel = new ErrorLogCreateCommandModel();

        errorLogCreateCommandModel.message = message;
        errorLogCreateCommandModel.severity = severity;
        errorLogCreateCommandModel.applicationId = environment.applicationId;
        this.createErrorLog(errorLogCreateCommandModel).subscribe();
    }

    private createErrorLog(errorLogCommandModel: ErrorLogCreateCommandModel): Observable<Response> {
        const headers = new HttpHeaders({ 'Context-Type': 'application/json' });

        const url = `${environment.endpoints.errorServiceUrl}/ErrorLogs`;
        return this.http
            .post<Response>(url, errorLogCommandModel, { headers })
            .pipe(catchError((err) => this.handleLocalError(err)));
    }

    // This one is private because if we get an error sending an error
    // there is not much we can do
    private handleLocalError(error: HttpErrorResponse) {
        const msg = `Error status code ${error.status} at ${error.url}`;
        console.log(msg);
        return throwError(error);
    }

    public handleHttpError(error: HttpErrorResponse, severity: ErrorSeverity): Observable<ErrorResponse> {
        const msg = `Error status code ${error.status} at ${error.url}`;
        const errorResponse = new ErrorResponse();
        errorResponse.message = msg;
        this.logError(msg, severity);
        return throwError(error);
    }
}
