import { inject, TestBed } from '@angular/core/testing';
import { ErrorParserService } from './error-parser.service';

describe('Service: ErrorParserService', () => {
    let service: ErrorParserService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ErrorParserService],
        });
        service = TestBed.get(ErrorParserService);
    });

    it('should ...', inject([ErrorParserService], (errorParserService: ErrorParserService) => {
        expect(errorParserService).toBeTruthy();
    }));

    it('should call parseErrorMessagesFromErrorResponse  ', () => {
        // Arrange
        const returnVal: string[] = ['Not Authorized! You need permission to access selected resource!'];
        const response = { status: 401, error: null };
        spyOn(service, 'parseErrorMessagesFromErrorResponse').and.returnValue(returnVal);

        // Act
        const messagesFromResponse = service.parseErrorMessagesFromErrorResponse(response);

        // Assert
        expect(service.parseErrorMessagesFromErrorResponse).toHaveBeenCalled();
    });

    it('should return response messages when there are error messages', () => {
        // Arrange
        const returnVal: string[] = ['Item already exist', 'Need select new item'];
        const response = {
            status: 404,
            error: { [0]: 'Item already exist', [1]: 'Need select new item' },
        };

        // Act
        const messagesFromResponse = service.parseErrorMessagesFromErrorResponse(response);

        // Assert
        expect(messagesFromResponse).toEqual(returnVal);
    });

    it('should return unauthorized message when status is 401 and no message in response', () => {
        // Arrange
        const returnVal: string[] = ['Not Authorized! You need permission to access selected resource!'];
        const response = { status: 401, error: null };

        // Act
        const messagesFromResponse = service.parseErrorMessagesFromErrorResponse(response);

        // Assert
        expect(messagesFromResponse).toEqual(returnVal);
    });

    it('should return unknown message when status is other and no message in response', () => {
        // Arrange
        const returnVal: string[] = ['Error response with unknown messages.'];
        const response = { status: 500, error: null };

        // Act
        const messagesFromResponse = service.parseErrorMessagesFromErrorResponse(response);

        // Assert
        expect(messagesFromResponse).toEqual(returnVal);
    });

    it('should return unknown error on null response', () => {
        // Arrange
        const returnVal: string[] = ['Unknown Error.'];

        // Act
        const messagesFromResponse = service.parseErrorMessagesFromErrorResponse(null);

        // Assert
        expect(messagesFromResponse).toEqual(returnVal);
    });
});
