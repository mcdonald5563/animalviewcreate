import { AuthorizedPermission } from './authorized-permission.model';

export class UserSecurityInfo {
    personId?: number;
    loginId: number;
    contactName: string;
    authorizedPermissions: AuthorizedPermission[];
}
