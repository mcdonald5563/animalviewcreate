export class AuthorizedPermission {
    permissionId: number;
    permissionCode: string;
    inventoryOrgId?: number;
}
