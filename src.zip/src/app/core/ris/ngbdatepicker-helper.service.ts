import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

@Injectable({
    providedIn: 'root',
})
export class NgbDatePickerHelperService {
    datePipe = new DatePipe('en-US');
    dateFormat = 'dd-MMM-yyyy';

    constructor() {}
    public toUtcDateTime(dateStruct: NgbDateStruct): string {
        return dateStruct !== null &&
            dateStruct !== undefined &&
            isNaN(dateStruct.day) !== true &&
            isNaN(dateStruct.month) !== true &&
            isNaN(dateStruct.year) !== true
            ? new Date(dateStruct.year, dateStruct.month - 1, dateStruct.day).toISOString()
            : null;
    }

    public toNgbDateStruct(date: Date): NgbDateStruct {
        return date !== null && date !== undefined
            ? { day: date.getUTCDay(), month: date.getUTCMonth() + 1, year: date.getUTCFullYear() }
            : null;
    }

    public toDateFormat(date: Date): string {
        return date !== null && date !== undefined ? this.datePipe.transform(date, this.dateFormat) : null;
    }
}
