/* tslint:disable:no-unused-variable */
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';

import { CollapseComponent } from './collapse.component';

describe('CollapseComponent', () => {
    let component: CollapseComponent;
    let fixture: ComponentFixture<CollapseComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [NgbCollapseModule],
            declarations: [CollapseComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CollapseComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
