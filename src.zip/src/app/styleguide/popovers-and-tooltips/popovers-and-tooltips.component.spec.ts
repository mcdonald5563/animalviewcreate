/* tslint:disable:no-unused-variable */
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { PopoversAndTooltipsComponent } from './popovers-and-tooltips.component';

describe('PopoversAndTooltipsComponent', () => {
    let component: PopoversAndTooltipsComponent;
    let fixture: ComponentFixture<PopoversAndTooltipsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [NgbModule, RouterTestingModule],
            declarations: [PopoversAndTooltipsComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(PopoversAndTooltipsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
