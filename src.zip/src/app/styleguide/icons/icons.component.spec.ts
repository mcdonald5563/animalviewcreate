/* tslint:disable:no-unused-variable */
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgbTab, NgbTabset } from '@ng-bootstrap/ng-bootstrap';
import { IconsComponent } from './icons.component';

describe('IconsComponent', () => {
    let component: IconsComponent;
    let fixture: ComponentFixture<IconsComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [IconsComponent, NgbTab, NgbTabset],
        }).compileComponents();
        fixture = TestBed.createComponent(IconsComponent);
        component = fixture.componentInstance;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
