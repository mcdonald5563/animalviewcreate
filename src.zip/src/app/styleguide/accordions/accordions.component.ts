import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-accordions',
    templateUrl: './accordions.component.html',
    styleUrls: ['./accordions.component.scss'],
})
export class AccordionsComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
