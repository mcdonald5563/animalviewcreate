import { Component, OnInit } from '@angular/core';
import { Scroll } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BasicModalComponent } from './basic-modal/basic-modal.component';
import { FormModalComponent } from './form-modal/form-modal.component';
import { ScrollableModalComponent } from './scrollable-modal/scrollable-modal.component';

@Component({
    selector: 'app-modals',
    templateUrl: './modals.component.html',
    styleUrls: ['./modals.component.scss'],
})
export class ModalsComponent implements OnInit {
    constructor(private modalService: NgbModal) {}

    ngOnInit() {}

    public openBasicModal() {
        this.modalService.open(BasicModalComponent);
    }

    public openBasicModalSm() {
        this.modalService.open(BasicModalComponent, { size: 'sm' });
    }

    public openBasicModalLg() {
        this.modalService.open(BasicModalComponent, { size: 'lg' });
    }

    public openBasicModalXl() {
        this.modalService.open(BasicModalComponent, { size: 'lg' });
    }

    public openScrollableModal() {
        this.modalService.open(ScrollableModalComponent);
    }

    public openFormModal() {
        this.modalService.open(FormModalComponent);
    }
}
