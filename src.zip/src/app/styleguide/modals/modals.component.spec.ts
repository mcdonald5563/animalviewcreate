/* tslint:disable:no-unused-variable */
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { RouterTestingModule } from '@angular/router/testing';
import { ModalsComponent } from './modals.component';

describe('ModalsComponent', () => {
    let component: ModalsComponent;
    let fixture: ComponentFixture<ModalsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [NgbModule, RouterTestingModule],
            declarations: [ModalsComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ModalsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
