import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertifyService } from '../../../core/ris/alertify.service';

@Component({
    selector: 'app-form-modal',
    templateUrl: './form-modal.component.html',
    styleUrls: ['./form-modal.component.scss'],
})
export class FormModalComponent implements OnInit {
    constructor(public activeModal: NgbActiveModal, private alertify: AlertifyService) {}

    ngOnInit() {}

    public save() {
        this.activeModal.close();
        this.alertify.success('Changes saved successfully', '');
    }

    public close() {
        this.activeModal.close();
    }
}
