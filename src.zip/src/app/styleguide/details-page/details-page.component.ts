import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-details-page',
    templateUrl: './details-page.component.html',
    styleUrls: ['./details-page.component.scss'],
})
export class DetailsPageComponent implements OnInit {
    isEntirePageLoading: boolean;
    isIndividualElementLoading: boolean;
    showLgCollapsibleText: boolean;
    showMdCollapsibleText: boolean;
    showSmCollapsibleText: boolean;

    constructor() {
        this.isEntirePageLoading = false;
        this.isIndividualElementLoading = false;
        this.showLgCollapsibleText = false;
        this.showMdCollapsibleText = false;
        this.showSmCollapsibleText = false;
    }

    public toggleLoadingforEntirePage() {
        this.isEntirePageLoading = !this.isEntirePageLoading;
    }

    public toggleLoadingforIndividualElements() {
        this.isIndividualElementLoading = !this.isIndividualElementLoading;
    }

    ngOnInit() {}
}
