/* tslint:disable:no-unused-variable */
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FusionChartsModule } from 'angular-fusioncharts';
import { ChartsComponent } from './charts.component';

describe('ChartsComponent', () => {
    let component: ChartsComponent;
    let fixture: ComponentFixture<ChartsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ChartsComponent],
            schemas: [NO_ERRORS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ChartsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('pieChart should be of type pie2d', () => {
        expect(component.pieChartViewModel.chartConfig['type']).toBe('pie2d');
    });
});
