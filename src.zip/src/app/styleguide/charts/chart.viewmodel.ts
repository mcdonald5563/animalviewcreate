export class ChartViewModel {
    public chartDataSource: object;
    public chartConfig: object;
    public showChart: boolean;
}
