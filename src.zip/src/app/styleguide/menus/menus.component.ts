import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-menus',
    templateUrl: './menus.component.html',
    styleUrls: ['./menus.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class MenusComponent implements OnInit {
    isNavbarCollapsed: boolean;
    constructor() {
        this.isNavbarCollapsed = true;
    }
    ngOnInit() {}
}
