import { Component, OnInit } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

@Component({
    selector: 'app-http-responses',
    templateUrl: './http-responses.component.html',
    styleUrls: ['./http-responses.component.scss'],
})
export class HttpResponsesComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
