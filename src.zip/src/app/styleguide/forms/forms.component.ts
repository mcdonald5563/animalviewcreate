import { Component, OnInit } from '@angular/core';

class Animal {
    id?: number;
    species: string;
    class: string;
    lifeSpan: number;
}
// tslint:disable-next-line: max-classes-per-file
@Component({
    selector: 'app-forms',
    templateUrl: './forms.component.html',
    styleUrls: ['./forms.component.scss'],
})
export class FormsComponent implements OnInit {
    isInvalid: boolean;
    selectedAnimal: string;
    isLoadingOn: boolean;
    public animals: Animal[] = [
        {
            id: 1,
            species: 'Blue Whale',
            class: 'Mammalia',
            lifeSpan: 110,
        },
        {
            id: 2,
            species: 'Giraffe',
            class: 'Mammalia',
            lifeSpan: 25,
        },
        {
            id: 3,
            species: 'Horse',
            class: 'Mammalia',
            lifeSpan: 35,
        },
        {
            id: 4,
            species: 'Cow',
            class: 'Mammalia',
            lifeSpan: 17,
        },
        {
            id: 5,
            species: 'Manatee',
            class: 'Mammalia',
            lifeSpan: 15,
        },
        {
            id: 6,
            species: 'Lion',
            class: 'Mammalia',
            lifeSpan: 20,
        },
        {
            id: 7,
            species: 'Ostrich',
            class: 'Aves',
            lifeSpan: 50,
        },
        {
            id: 8,
            species: 'Seal',
            class: 'Mammalia',
            lifeSpan: 13,
        },
        {
            id: 9,
            species: 'Hammerhead Shark',
            class: 'Chondrichthyes',
            lifeSpan: 18,
        },
        {
            id: 10,
            species: 'Goat',
            class: 'Mammalia',
            lifeSpan: 15,
        },
    ];

    constructor() {
        this.isInvalid = false;
        this.isLoadingOn = false;
    }

    ngOnInit() {}
}
