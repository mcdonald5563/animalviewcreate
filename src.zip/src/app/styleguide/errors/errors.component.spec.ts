/* tslint:disable:no-unused-variable */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ErrorSeverity } from '../../core/ris/error-log-create-commandmodel.model';
import { ErrorLogService } from '../../core/ris/error-log.service';
import { ErrorResponse } from '../../core/ris/error-response';
import { ErrorsComponent } from './errors.component';

describe('ErrorsComponent', () => {
    let component: ErrorsComponent;
    let fixture: ComponentFixture<ErrorsComponent>;

    class MockErrorService {
        logError(message: string, severity: ErrorSeverity): ErrorResponse {
            return null;
        }
    }
    beforeEach(() => {
        const mockErrorService = new MockErrorService();
        TestBed.configureTestingModule({
            imports: [NgbModule],
            declarations: [ErrorsComponent],
            providers: [{ provide: ErrorLogService, useValue: mockErrorService }],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ErrorsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
