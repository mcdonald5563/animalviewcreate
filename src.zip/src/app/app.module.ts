import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule, Title } from '@angular/platform-browser';
import { NgbDateParserFormatter, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AdalInterceptor, AdalService } from 'adal-angular4';
import { FusionChartsModule } from 'angular-fusioncharts';
import * as FusionCharts from '../app/fusion-charts/fusioncharts';
import * as Charts from '../app/fusion-charts/fusioncharts.charts';
import * as FusionTheme from '../app/fusion-charts/themes/fusioncharts.theme.fusion';
import { AppRoutingModule } from './app-routing-module';
import { AppComponent } from './app.component';
import { AlertifyService } from './core/ris/alertify.service';
import { NgbDatePickerParserFormatterService } from './core/ris/ngbdatepicker-parser-formatter.service';
import { HomeComponent } from './home/home.component';
import { NavComponent } from './nav/nav.component';
import { AccessDeniedComponent } from './ris/access-denied/access-denied.component';
import { AuthenticationCallbackComponent } from './ris/authentication/authentication-callback.component';
import { LoginComponent } from './ris/login/login.component';
import { NotFoundComponent } from './ris/not-found/not-found.component';
import { NovFooterComponent } from './ris/nov-footer/nov-footer.component';
import { RisModule } from './ris/ris.module';
import { SignOutComponent } from './ris/sign-out/sign-out.component';
import { SharedModule } from './shared/shared.module';
import { StyleguideComponent } from './styleguide/styleguide.component';
import {AnimalModule } from './animal/animal.module';


FusionChartsModule.fcRoot(FusionCharts, Charts, FusionTheme);
@NgModule({
    declarations: [
        AppComponent,
        NavComponent,
        HomeComponent,
        StyleguideComponent,
        AuthenticationCallbackComponent,
        LoginComponent,
        NotFoundComponent,
        NovFooterComponent,
        AccessDeniedComponent,
        SignOutComponent
        
    ],
    imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        NgbModule,
        SharedModule,
        AppRoutingModule,
        RisModule,
        FusionChartsModule,
        AnimalModule
    ],
    providers: [
        AlertifyService,
        AdalService,
        Title,
        { provide: HTTP_INTERCEPTORS, useClass: AdalInterceptor, multi: true },
        { provide: NgbDateParserFormatter, useFactory: () => new NgbDatePickerParserFormatterService() },
    ],
    bootstrap: [AppComponent],
})
export class AppModule {}
